/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

// -----------------------------------------------------------------------------
// INCLUDES
// -----------------------------------------------------------------------------

#include "precompiled.h"

#include <math.h>

#include <GL/glut.h>

#include "glwidget.h"

using namespace std;


// -----------------------------------------------------------------------------
// CONSTANTS
// -----------------------------------------------------------------------------

namespace
{
	const QColor	DEFAULT_BACKGROUND_COLOR = QColor(0, 0, 0);
	const int		DEFAULT_UPDATE_INTERVAL = -1;
	const float		DEFAULT_CUBE_SIZE = 0.5;
	const float		DEFAULT_TEAPOT_RADIUS = 0.3;
	const float		DEFAULT_SPHERE_RADIUS = 0.4;
	const int		DEFAULT_SPHERE_SLICES = 20;
	const int		DEFAULT_SPHERE_STACKS = 20;
	const float		DEFAULT_FLAG_WIDTH = 0.8;
	const float		DEFAULT_FLAG_HEIGHT = 0.48;
	const int		DEFAULT_FLAG_SLICES = 10;
	const int		DEFAULT_FLAG_STACKS = 8;
}


// -----------------------------------------------------------------------------
// MeshObjects
// -----------------------------------------------------------------------------

class MeshObject
{
public:
	virtual void draw() = 0;
};

// -----------------------------------------------------------------------------

class Teapot : public MeshObject
{
public:
	Teapot(float radius) :
		m_radius(radius)
	{
		if (m_radius <= 0) m_radius = DEFAULT_TEAPOT_RADIUS;
	}

	void draw()
	{
		glutSolidTeapot(m_radius);
	}

private:
	float m_radius;
};

// -----------------------------------------------------------------------------

class Cube : public MeshObject
{
public:
	Cube(float size) :
		m_size(size)
	{
		if (m_size <= 0) m_size = DEFAULT_CUBE_SIZE;
	}

	void draw()
	{
		glutSolidCube(m_size);
	}

private:
	float m_size;
};

// -----------------------------------------------------------------------------

class Sphere : public MeshObject
{
public:
	Sphere(float radius, int slices, int stacks) :
		m_radius(radius),
		m_slices(slices),
		m_stacks(stacks)
	{
		if (m_radius <= 0) m_radius = DEFAULT_SPHERE_RADIUS;
		if (m_slices <= 0) m_slices = DEFAULT_SPHERE_SLICES;
		if (m_stacks <= 0) m_stacks = DEFAULT_SPHERE_STACKS;
	}

	void draw()
	{
		glutSolidSphere(m_radius, m_slices, m_stacks);
	}

private:
	float	m_radius;
	int		m_slices;
	int		m_stacks;
};

// -----------------------------------------------------------------------------

class Flag : public MeshObject
{
public:
	Flag(float width, float height, int slices, int stacks) :
		m_width(width),
		m_height(height),
		m_slices(slices),
		m_stacks(stacks)
	{
		if (m_width <= 0) m_width = DEFAULT_FLAG_WIDTH;
		if (m_height <= 0) m_height = DEFAULT_FLAG_HEIGHT;
		if (m_slices <= 0) m_slices = DEFAULT_FLAG_SLICES;
		if (m_stacks <= 0) m_stacks = DEFAULT_FLAG_STACKS;
	}

	void draw()
	{
		float quadWidth = m_width / static_cast<float>(m_slices);
		float quadHeight = m_height / static_cast<float>(m_stacks);
		float sInc = 1.0f / static_cast<float>(m_slices);
		float tInc = 1.0f / static_cast<float>(m_stacks); 

		// glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)

		glBegin(GL_QUADS);
			float curY = -m_height / 2;
			float curT = 0;
			for (int y = 0; y < m_stacks; ++y)
			{
				float curX = - m_width / 2;
				float curS = 0;
				for (int x = 0; x < m_slices; ++x)
				{
					glTexCoord2f(curS, curT);
					glVertex3f(curX, curY, 0);
					glTexCoord2f(curS + sInc, curT);
					glVertex3f(curX + quadWidth, curY, 0);
					glTexCoord2f(curS + sInc, curT + tInc);
					glVertex3f(curX + quadWidth, curY + quadHeight, 0);
					glTexCoord2f(curS, curT + tInc);
					glVertex3f(curX, curY + quadHeight, 0);

					curX += quadWidth;
					curS += sInc;
				}

				curY += quadHeight;
				curT += tInc;
			}
		glEnd();
	}

private:
	float m_width;
	float m_height;
	int m_slices;
	int m_stacks;
};

// -----------------------------------------------------------------------------

GLWidget::GLWidget(QWidget *parent) :
	QGLWidget(parent),
	m_shaderSupported(false),
	m_vertexShaderObj(0),
	m_pixelShaderObj(0),
	m_programObj(0),
	m_GLresetNeeded(true),
	m_object(0),
	m_updateTimer(this),
	m_timeUniformLocation(-1),
	m_randomUniformLocation(-1)
{
	connect(&m_updateTimer, SIGNAL(timeout()), this, SLOT(update()));
	makeCurrent();

	if (glewInit() != GLEW_OK)
	{
		cerr << __FUNCTION__ << " - glewInit() failed" << endl;
		m_shaderSupported = false;
	}
	else
	{
		m_shaderSupported = GLEW_ARB_multitexture && 
							GLEW_ARB_shader_objects &&
							GLEW_ARB_vertex_shader &&
							GLEW_ARB_fragment_shader;
	}

	if (m_shaderSupported) reset();
}

GLWidget::~GLWidget()
{
	deleteShaderObjects();
}

void GLWidget::reset()
{
	m_xRot = 0;
	m_yRot = 0;
	m_zRot = 0;

	setUpdateInterval(DEFAULT_UPDATE_INTERVAL);
	setNothing();
	setBackgroundColor(DEFAULT_BACKGROUND_COLOR);
	deleteShaderObjects();
}

void GLWidget::setNothing()
{
	m_object.reset(0);
}

void GLWidget::setTeapot(float radius)
{
	m_object.reset(new Teapot(radius));
}

void GLWidget::setCube(float size)
{
	m_object.reset(new Cube(size));
}

void GLWidget::setSphere(float radius, int slices, int stacks)
{
	m_object.reset(new Sphere(radius, slices, stacks));
}

void GLWidget::setFlag(float width, float height, int slices, int stacks)
{
	m_object.reset(new Flag(width, height, slices, stacks));
}

QSize GLWidget::minimumSizeHint() const
{
	return QSize(50, 50);
}

QSize GLWidget::sizeHint() const
{
	return QSize(400, 400);
}

void GLWidget::setXRotation(int angle)
{
	normalizeAngle(&angle);
	if (angle != m_xRot) {
		m_xRot = angle;
		updateGL();
	}
}

void GLWidget::setYRotation(int angle)
{
	normalizeAngle(&angle);
	if (angle != m_yRot) {
		m_yRot = angle;
		updateGL();
	}
}

void GLWidget::setZRotation(int angle)
{
	normalizeAngle(&angle);
	if (angle != m_zRot) {
		m_zRot = angle;
		updateGL();
	}
}

void GLWidget::setBackgroundColor(QColor color)
{
	if (color.isValid())
	{
		m_backgroundColor = color;
		m_GLresetNeeded = true;
	}
	else
		cerr << __FUNCTION__ << " - Invalid color" << endl;
}

void GLWidget::setUpdateInterval(int updateInterval)
{
	if (updateInterval >= 0)
	{
		m_updateTimer.setInterval(updateInterval);
		m_updateTimer.start();
	}
	else
	{
		m_updateTimer.stop();
	}
}

void GLWidget::setTexture(const QString & file, unsigned int unit)
{
	m_textureMap[unit] = file;
}

void GLWidget::resetGL()
{
	qglClearColor(m_backgroundColor);
	glShadeModel(GL_SMOOTH);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);

	GLfloat lightAmbient[4]= { 0.2f, 0.2f, 0.2f, 1.0f };
	GLfloat lightDiffuse[4]= { 0.8f, 0.8f, 0.8f, 1.0f };
	GLfloat lightSpecular[4] = { 0.3f, 0.3f, 0.3f, 1.0f };
	GLfloat lightPos[4] = {0.84,0.42,0.337,0};
	glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmbient);	
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDiffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpecular);
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
	glEnable(GL_LIGHT0);

	GLfloat materialDiffuse[4] = { 0.2f, 0.8f, 0.2f, 1.0f };
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, materialDiffuse);

	for (TextureMapCIter it = m_textureMap.begin(); it != m_textureMap.end(); ++it)
	{
		if (it->first < 32)
		{
			glActiveTextureARB(GL_TEXTURE0_ARB + it->first);
			bindTexture(QPixmap(it->second));
			glEnable(GL_TEXTURE_2D);
		}
	}

	glGetError();
}

void GLWidget::initializeGL()
{
}

void GLWidget::paintGL()
{
	if (m_GLresetNeeded)
	{
		resetGL();
		m_GLresetNeeded = false;
	}
	
	if (m_timeUniformLocation >= 0)
	{
		float time = m_time.elapsed() / 1000.0f;
		glUniform1fARB(m_timeUniformLocation, time);
	}

	if (m_randomUniformLocation >= 0)
	{
		float random = rand() / static_cast<float>(RAND_MAX);
		glUniform1fARB(m_randomUniformLocation, random);
	}

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	glTranslated(0.0, 0.0, -10.0);

	glRotated(m_xRot / 16.0, 1.0, 0.0, 0.0);
	glRotated(m_yRot / 16.0, 0.0, 1.0, 0.0);
	glRotated(m_zRot / 16.0, 0.0, 0.0, 1.0);

	if (m_programObj)
	{
		glUseProgramObjectARB(m_programObj);
		if (m_object.get()) m_object->draw();

		glUniform1iARB(glGetUniformLocationARB(m_programObj, "tex0"), 0);
		glUniform1iARB(glGetUniformLocationARB(m_programObj, "tex1"), 1);
		glGetError();
	}

	/*
	glActiveTextureARB(GL_TEXTURE0_ARB); 
	glBindTexture(GL_TEXTURE_2D, 0);
	glDisable(GL_TEXTURE_2D);

	glActiveTextureARB(GL_TEXTURE1_ARB); 
	glBindTexture(GL_TEXTURE_2D, 0);
	glDisable(GL_TEXTURE_2D);
	*/
}

void GLWidget::resizeGL(int width, int height)
{
	int side = qMin(width, height);
	glViewport((width - side) / 2, (height - side) / 2, side, side);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-0.5, +0.5, -0.5, +0.5, 4.0, 15.0);
	glMatrixMode(GL_MODELVIEW);
}

void GLWidget::mousePressEvent(QMouseEvent *event)
{
	m_lastPos = event->pos();
}

void GLWidget::mouseMoveEvent(QMouseEvent *event)
{
	int dx = event->x() - m_lastPos.x();
	int dy = event->y() - m_lastPos.y();

	if (event->buttons() & Qt::LeftButton) {
		setXRotation(m_xRot + 8 * dy);
		setYRotation(m_yRot + 8 * dx);
	} else if (event->buttons() & Qt::RightButton) {
		setXRotation(m_xRot + 8 * dy);
		setZRotation(m_zRot + 8 * dx);
	}
	m_lastPos = event->pos();
}

void GLWidget::normalizeAngle(int *angle)
{
	while (*angle < 0)
		*angle += 360 * 16;
	while (*angle > 360 * 16)
		*angle -= 360 * 16;
}

// -----------------------------------------------------------------------------

namespace
{
	QString getInfoLog(GLhandleARB obj)
	{
		int infoLogLength = 0;
		glGetObjectParameterivARB(obj, GL_OBJECT_INFO_LOG_LENGTH_ARB, &infoLogLength);

		if (infoLogLength >= 2)
		{
			QByteArray infoLog(infoLogLength, ' ');
			GLsizei charsWritten  = 0;
			glGetInfoLogARB(obj, infoLogLength, &charsWritten, reinterpret_cast<GLcharARB *>(infoLog.data()));
			QString result(infoLog);
			result += "\n";
			return result;
		}
		else
			return "";
	}

	QString makeGLErrorMessage(const char * functionName, GLenum errorCode)
	{
		QString msg;
		QTextStream msgStream(&msg);
		msgStream << "OpenGL error " << errorCode << " in function " << functionName << "\n";
		return msg;
	}

#define XXX(name) case name: return #name
	const char * shaderTypeToString(GLenum type)
	{
		switch (type)
		{
			XXX(GL_FLOAT);
			XXX(GL_FLOAT_VEC2);
			XXX(GL_FLOAT_VEC3);
			XXX(GL_FLOAT_VEC4);
			XXX(GL_INT);
			XXX(GL_INT_VEC2);
			XXX(GL_INT_VEC3);
			XXX(GL_INT_VEC4);
			XXX(GL_BOOL);
			XXX(GL_BOOL_VEC2);
			XXX(GL_BOOL_VEC3);
			XXX(GL_BOOL_VEC4);
			XXX(GL_FLOAT_MAT2);
			XXX(GL_FLOAT_MAT3);
			XXX(GL_FLOAT_MAT4);
			XXX(GL_SAMPLER_1D);
			XXX(GL_SAMPLER_2D);
			XXX(GL_SAMPLER_3D);
			XXX(GL_SAMPLER_CUBE);
			XXX(GL_SAMPLER_1D_SHADOW);
			XXX(GL_SAMPLER_2D_SHADOW);
			default:
				return "unknown";
		}
	}
#undef XXX

/*
	void dumpActiveUniforms(GLhandleARB programObj)
	{
		GLint activeUniforms;
		glGetProgramiv(programObj, GL_ACTIVE_UNIFORMS, &activeUniforms);
		GLint activeUniformMaxLength;
		glGetProgramiv(programObj, GL_ACTIVE_UNIFORM_MAX_LENGTH, &activeUniformMaxLength);
		
		cerr << activeUniforms << " active uniforms" << endl << endl;

		QByteArray nameBuffer(activeUniformMaxLength, 0);
		for (GLint i = 0; i < activeUniforms; ++i)
		{
			GLsizei length;
			GLint size;
			GLenum type;

			glGetActiveUniform(programObj, i, nameBuffer.size(), &length, &size, &type, nameBuffer.data());

			cerr << "Name: " << QString(nameBuffer).toStdString() << endl;
			cerr << "Size: " << size << endl;
			cerr << "Type: " << shaderTypeToString(type) << endl;
		}

		glGetError();
	}
*/
}

void GLWidget::compileAndUseShaders(const QString & vertexShader, const QString & pixelShader)
{
	deleteShaderObjects();
	
	GLenum error;

	m_vertexShaderObj = glCreateShaderObjectARB(GL_VERTEX_SHADER_ARB);
	m_pixelShaderObj = glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);
	error = glGetError();
	if (error != 0)
	{
		emit compilerOutput(makeGLErrorMessage("glCreateShaderObjectARB()", error));
		return;
	}

	QByteArray vertexShaderBytes = vertexShader.toAscii();
	QByteArray pixelShaderBytes = pixelShader.toAscii();
	const GLcharARB * vertexShaderBytesData = vertexShaderBytes.data();
	const GLcharARB * pixelShaderBytesData = pixelShaderBytes.data();
	glShaderSourceARB(m_vertexShaderObj, 1, &vertexShaderBytesData, 0);
	glShaderSourceARB(m_pixelShaderObj, 1, &pixelShaderBytesData, 0);
	error = glGetError();
	if (error != 0)
	{
		emit compilerOutput(makeGLErrorMessage("glShaderSourceARB()", error));
		return;
	}


	emit compilerOutput(tr("Compiliere Vertex Shader ..."));
	emit compilerOutput("\n");
	glCompileShaderARB(m_vertexShaderObj);
	emit compilerOutput(getInfoLog(m_vertexShaderObj));

	emit compilerOutput(tr("Compiliere Pixel Shader ..."));
	emit compilerOutput("\n");
	glCompileShaderARB(m_pixelShaderObj);
	emit compilerOutput(getInfoLog(m_pixelShaderObj));

	m_programObj = glCreateProgramObjectARB();
	error = glGetError();
	if (error != 0)
	{
		emit compilerOutput(makeGLErrorMessage("glCreateProgramObjectARB()", error));
		return;
	}

	glAttachObjectARB(m_programObj, m_vertexShaderObj);
	glAttachObjectARB(m_programObj, m_pixelShaderObj);
	error = glGetError();
	if (error != 0)
	{
		emit compilerOutput(makeGLErrorMessage("glAttachObjectARB()", error));
		return;
	}

	glLinkProgramARB(m_programObj);
	emit compilerOutput(getInfoLog(m_programObj));

	glUseProgramObjectARB(m_programObj);
	error = glGetError();
	if (error != 0)
	{
		emit compilerOutput(makeGLErrorMessage("glUseProgramObjectARB()", error));
		return;
	}

	m_timeUniformLocation = glGetUniformLocationARB(m_programObj, "time");
	error = glGetError();
	if (error != 0)
	{
		emit compilerOutput(makeGLErrorMessage("glGetUniformLocationARB()", error));
		return;
	}

	m_randomUniformLocation = glGetUniformLocationARB(m_programObj, "random");
	error = glGetError();
	if (error != 0)
	{
		emit compilerOutput(makeGLErrorMessage("glGetUniformLocationARB()", error));
		return;
	}

	m_time.restart();

	update();
}

void GLWidget::deleteShaderObjects()
{
	glUseProgramObjectARB(0);
	if (m_vertexShaderObj)
	{
		if (m_programObj) glDetachObjectARB(m_programObj, m_vertexShaderObj);
		glDeleteObjectARB(m_vertexShaderObj);
		m_vertexShaderObj = 0;
	}
	if (m_pixelShaderObj)
	{
		if (m_programObj) glDetachObjectARB(m_programObj, m_pixelShaderObj);
		glDeleteObjectARB(m_pixelShaderObj);
		m_pixelShaderObj = 0;
	}
	if (m_programObj)
	{
		glUseProgramObjectARB(0);
		glDeleteObjectARB(m_programObj);
		m_programObj = 0;
	}
	glGetError();
}
