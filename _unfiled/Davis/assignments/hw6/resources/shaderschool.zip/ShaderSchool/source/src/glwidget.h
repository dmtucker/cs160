/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QtOpenGL\QGLWidget>
#include <QtCore\QTimer>
#include <QtCore\QTime>

class ShaderUniform;
class MeshObject;

class GLWidget : public QGLWidget
{
	Q_OBJECT

public:
	GLWidget(QWidget *parent = 0);
	~GLWidget();

	QSize minimumSizeHint() const;
	QSize sizeHint() const;
	int xRotation() const { return m_xRot; }
	int yRotation() const { return m_yRot; }
	int zRotation() const { return m_zRot; }

	QColor backgroundColor() const { return m_backgroundColor; }
	bool shaderSupported() const { return m_shaderSupported; }
	int updateInterval() const { if (m_updateTimer.isActive()) return m_updateTimer.interval(); else return -1; }

public slots:
	void setXRotation(int angle);
	void setYRotation(int angle);
	void setZRotation(int angle);
	void compileAndUseShaders(const QString & vertexShader, const QString & pixelShader);
	void setBackgroundColor(QColor color);
	void reset();
	void setUpdateInterval(int updateInterval);
	void setNothing();
	void setTeapot(float radius = -1);
	void setCube(float size = -1);
	void setSphere(float radius = -1, int slices = -1, int stacks = -1);
	void setFlag(float width = -1, float height = -1, int slices = -1, int stacks = -1);
	void setTexture(const QString & file, unsigned int unit);

signals:
	void compilerOutput(QString message);

protected slots:
	void initializeGL();
	void paintGL();
	void resizeGL(int width, int height);
	void mousePressEvent(QMouseEvent *event);
	void mouseMoveEvent(QMouseEvent *event);

private:
	void normalizeAngle(int *angle);
	void resetGL();
	void deleteShaderObjects();

	int m_xRot;
	int m_yRot;
	int m_zRot;
	QPoint m_lastPos;

	bool						m_GLresetNeeded;
	bool						m_shaderSupported;
	QColor						m_backgroundColor;
	std::auto_ptr<MeshObject>	m_object;
	QTimer						m_updateTimer;

	GLuint	m_vertexShaderObj;
	GLuint	m_pixelShaderObj;
	GLuint	m_programObj;

	std::map<unsigned int, QString> m_textureMap;
	typedef std::map<unsigned int, QString>::const_iterator TextureMapCIter;

	GLint m_timeUniformLocation;
	GLint m_randomUniformLocation;
	QTime m_time;
};

#endif
