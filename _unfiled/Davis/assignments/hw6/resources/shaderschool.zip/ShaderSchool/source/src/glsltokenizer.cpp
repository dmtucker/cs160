/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

// -----------------------------------------------------------------------------
// INCLUDES
// -----------------------------------------------------------------------------

#include "precompiled.h"

#include "glsltokenizer.h"


// -----------------------------------------------------------------------------

using namespace std;
typedef string::const_iterator Iter;

// -----------------------------------------------------------------------------
// CONSTANTS
// -----------------------------------------------------------------------------

namespace
{
	const char * PREPROCESSOR_DIRECTIVES[] =
	{
		"define",
		"undef",
		"if",
		"ifdef",
		"ifndef",
		"else",
		"elif",
		"endif",
		"error",
		"pragma",
		"extension",
		"version",
		"line",
		"",
		0
	};

	const char * KEYWORDS[] =
	{
		"attribute",
		"const",
		"uniform",
		"varying",
		"break",
		"continue",
		"do",
		"for",
		"while",
		"if",
		"else",
		"in",
		"out",
		"inout",
		"float",
		"int",
		"void",
		"bool",
		"true",
		"false",
		"discard",
		"return",
		"mat2",
		"mat3",
		"mat4",
		"vec2",
		"vec3",
		"vec4",
		"ivec2",
		"ivec3",
		"ivec4",
		"bvec2",
		"bvec3",
		"bvec4",
		"sampler1D",
		"sampler2D",
		"sampler3D",
		"samplerCube",
		"sampler1DShadow",
		"sampler2DShadow",
		"struct",
		0
	};

	const char * FUNCTIONS[] =
	{
		"radians",
		"degrees",
		"sin",
		"cos",
		"tan",
		"asin",
		"acos",
		"atan",
		"pow",
		"exp",
		"log",
		"exp2",
		"log2",
		"sqrt",
		"inversesqrt",
		"abs",
		"sign",
		"floor",
		"ceil",
		"fract",
		"mod",
		"min",
		"max",
		"clamp",
		"mix",
		"step",
		"smoothstep",
		"length",
		"distance",
		"dot",
		"cross",
		"normalize",
		"ftransform",
		"faceforward",
		"reflect",
		"refract",
		"matrixCompMult",
		"lessThan",
		"lessThanEqual",
		"greaterThan",
		"greaterThanEqual",
		"equal",
		"notEqual",
		"any",
		"all",
		"not",
		"texture1D",
		"texture1DProj",
		"texture1DLod",
		"texture1DProjLod",
		"texture2D",
		"texture2DProj",
		"texture2DLod",
		"texture2DProjLod",
		"texture3D",
		"texture3DProj",
		"texture3DLod",
		"texture3DProjLod",
		"textureCube",
		"textureCubeLod",
		"shadow1D",
		"shadow1DProj",
		"shadow1DLod",
		"shadow1DProjLod",
		"shadow2D",
		"shadow2DProj",
		"shadow2DLod",
		"shadow2DProjLod",
		"dFdx",
		"dFdy",
		"fwidth",
		"noise1",
		"noise2",
		"noise3",
		"noise4",
		0
	};

	const char * VARIABLES[] =
	{
		"gl_ModelViewMatrix",
		"gl_ProjectionMatrix",
		"gl_ModelViewProjectionMatrix",
		"gl_TextureMatrix",
		"gl_NormalMatrix",
		"gl_ModelViewMatrixInverse",
		"gl_ProjectionMatrixInverse",
		"gl_ModelViewProjectionMatrixInverse",
		"gl_TextureMatrixInverse",
		"gl_ModelViewMatrixTranspose",
		"gl_ProjectionMatrixTranspose",
		"gl_ModelViewProjectionMatrixTranspose",
		"gl_TextureMatrixTranspose",
		"gl_ModelViewMatrixInverseTranspose",
		"gl_ProjectionMatrixInverseTranspose",
		"gl_ModelViewProjectionMatrixInverseTranspose",
		"gl_TextureMatrixInverseTranspose",
		"gl_NormalScale",
		"gl_DepthRange",
		"gl_ClipPlane",
		"gl_Point",
		"gl_FrontMaterial",
		"gl_BackMaterial",
		"gl_LightSource",
		"gl_LightModel",
		"gl_FrontLightModelProduct",
		"gl_BackLightModelProduct",
		"gl_FrontLightProduct",
		"gl_BackLightProduct",
		"gl_TextureEnvColor",
		"gl_EyePlaneS",
		"gl_EyePlaneT",
		"gl_EyePlaneR",
		"gl_EyePlaneQ",
		"gl_ObjectPlaneS",
		"gl_ObjectPlaneT",
		"gl_ObjectPlaneR",
		"gl_ObjectPlaneQ",
		"gl_Fog",
		"gl_FrontColor",
		"gl_BackColor",
		"gl_FrontSecondaryColor",
		"gl_BackSecondaryColor",
		"gl_TexCoord",
		"gl_FogFragCoord",
		"gl_Color",
		"gl_SecondaryColor",
		"gl_TexCoord",
		"gl_FogFragCoord",
		"gl_Position",
		"gl_PointSize",
		"gl_ClipVertex",
		"gl_FragCoord",
		"gl_FrontFacing",
		"gl_FragColor",
		"gl_FragData",
		"gl_FragDepth",
		"gl_Color",
		"gl_SecondaryColor",
		"gl_Normal",
		"gl_Vertex",
		"gl_MultiTexCoord0",
		"gl_MultiTexCoord1",
		"gl_MultiTexCoord2",
		"gl_MultiTexCoord3",
		"gl_MultiTexCoord4",
		"gl_MultiTexCoord5",
		"gl_MultiTexCoord6",
		"gl_MultiTexCoord7",
		"gl_FogCoord",
		"gl_MaxLights",
		"gl_MaxClipPlanes",
		"gl_MaxTextureUnits",
		"gl_MaxTextureCoords",
		"gl_MaxVertexAttribs",
		"gl_MaxVertexUniformComponents",
		"gl_MaxVaryingFloats",
		"gl_MaxVertexTextureImageUnits",
		"gl_MaxCombinedTextureImageUnits",
		"gl_MaxTextureImageUnits",
		"gl_MaxFragmentUniformComponents",
		"gl_MaxDrawBuffers",
		0
	};

	const char * MACROS[] =
	{
		"__LINE__",
		"__FILE__",
		"__VERSION__",
		0
	};

	bool my_isalpha(int c)
	{
		return (c >= 'a' && c <= 'z') ||
			   (c >= 'A' && c <= 'Z');
	}

	bool my_isdigit(int c)
	{
		return c >= '0' && c <= '9';
	}
}


// -----------------------------------------------------------------------------

#include <iostream>
class GLSLTokenizer::GLSLTokenizer_Private
{
public:

	// -------------------------------------------------------------------------
	
	GLSLTokenizer_Private()
	{
		if (!m_stringSetsSetup)
		{
			setupStringSets();
			m_stringSetsSetup = true;
		}
	}

	// -------------------------------------------------------------------------

	void reset(const string & text)
	{
		m_pos = text.begin();
		m_end = text.end();
	}

	// -------------------------------------------------------------------------

	GLSLToken getNextToken(bool inBlockComment = false)
	{
		if (inBlockComment)
		{
			if (m_pos == m_end)
				return GLSLToken(GLSLToken::END_OF_FILE, m_pos, m_pos);
			else
			{
				Iter start = m_pos;
				bool blockCommentEnded = eatBlockComment();
				return GLSLToken(blockCommentEnded ? GLSLToken::BLOCK_COMMENT_END : GLSLToken::BLOCK_COMMENT,
								 start, m_pos);
			}
		}

		while (!eof())
		{
			int c = nextChar();

			switch (c)
			{
			// Whitespace
			case ' ':
			case '\t':
				{
					Iter start = m_pos - 1;
					eatWhiteSpace();
					return GLSLToken(GLSLToken::WHITESPACE, start, m_pos);
				}
				break;

			// Kommentare
			case '/':
				{
					// Line-Kommentar
					if (peekNextChar() == '/')
					{
						Iter start = m_pos - 1;
						eatUntilNewline();
						return GLSLToken(GLSLToken::LINE_COMMENT, start, m_pos);
					}
					// Block-Kommentar
					else if (peekNextChar() == '*')
					{
						Iter start = m_pos - 1;
						bool blockCommentEnded = eatBlockComment();
						return GLSLToken(blockCommentEnded ? GLSLToken::BLOCK_COMMENT_END : GLSLToken::BLOCK_COMMENT,
										 start, m_pos);
					}
					else
						return GLSLToken(GLSLToken::UNKNOWN, m_pos - 1, m_pos);
				}
				break;

			// Pr�prozessor Direktiven
			case '#':
				{
					Iter start = m_pos - 1;
					eatIdentifier();

					if (isStringInSet(start + 1, m_pos, m_preprocessorDirectives))
						return GLSLToken(GLSLToken::PREPROCESSOR_DIRECTIVE, start, m_pos);
					else
						return GLSLToken(GLSLToken::UNKNOWN, start, m_pos);
				}
				break;

			// Build-In Macros
			case '_':
				{
					if (peekNextChar() == '_')
					{
						Iter start = m_pos - 1;
						eatIdentifier();

						if (isStringInSet(start, m_pos, m_macros))
							return GLSLToken(GLSLToken::MACRO, start, m_pos);
						else
							return GLSLToken(GLSLToken::UNKNOWN, start, m_pos);
					}
				}
				break;

			// Alles andere (Bezeichner, Operatoren, Klammern, etc...)
			default:
				{
					if (c == '_' || my_isalpha(c))
					{
						Iter start = m_pos - 1;
						eatIdentifier();

						if (isStringInSet(start, m_pos, m_keywords))
							return GLSLToken(GLSLToken::KEYWORD, start, m_pos);
						else if (isStringInSet(start, m_pos, m_functions))
							return GLSLToken(GLSLToken::FUNCTION, start, m_pos);
						else if (isStringInSet(start, m_pos, m_variables))
							return GLSLToken(GLSLToken::VARIABLE, start, m_pos);
						else
							return GLSLToken(GLSLToken::UNKNOWN, start, m_pos);
					}
					else
						return GLSLToken(GLSLToken::UNKNOWN, m_pos - 1, m_pos);
				}
			}
		}
		
		return GLSLToken(GLSLToken::END_OF_FILE, m_pos, m_pos);
	}

private:

	// -------------------------------------------------------------------------

	bool isStringInSet(Iter start, Iter end, const set<string> & set) const
	{
		return set.find(string(start, end)) != set.end();
	}

	// -------------------------------------------------------------------------

	int nextChar()
	{
		int result = peekNextChar();
		++m_pos;
		return result;
	}

	// -------------------------------------------------------------------------

	int peekNextChar()
	{
		if (eof()) return -1;
		return *m_pos;
	}

	// -------------------------------------------------------------------------

	bool eof() const
	{
		return m_pos >= m_end;
	}

	// -------------------------------------------------------------------------

	bool eatBlockComment()
	{
		while (!eof())
		{
			int c = nextChar();
			if (c == '*' && peekNextChar() == '/')
			{
				nextChar();
				return true;
			}
		}

		return false;
	}

	// -------------------------------------------------------------------------

	void eatWhiteSpace()
	{
		while (!eof())
		{
			int c = peekNextChar();
			if (c != ' ' && c != '\t') break;
			nextChar();
		}
	}

	// -------------------------------------------------------------------------

	void eatUntilNewline()
	{
		while (!eof())
		{
			if (peekNextChar() == '\n')
				break;
			else
				nextChar();
		};
	}

	// -------------------------------------------------------------------------

	void eatIdentifier()
	{
		int c = peekNextChar();
		if (c != '_' && !my_isalpha(c)) return;
		nextChar();

		while (!eof())
		{
			int c = peekNextChar();
			if (c != '_' && !my_isalpha(c) && !my_isdigit(c)) return;
			nextChar();
		}
	}

	// -------------------------------------------------------------------------

	Iter	m_pos;
	Iter	m_end;

	// -------------------------------------------------------------------------

	void setupStringSets()
	{
		const char ** walker = PREPROCESSOR_DIRECTIVES;
		while (*walker)
		{
			m_preprocessorDirectives.insert(*walker);
			++walker;
		}
		
		walker = MACROS;
		while (*walker)
		{
			m_macros.insert(*walker);
			++walker;
		}

		walker = KEYWORDS;
		while (*walker)
		{
			m_keywords.insert(*walker);
			++walker;
		}

		walker = FUNCTIONS;
		while (*walker)
		{
			m_functions.insert(*walker);
			++walker;
		}

		walker = VARIABLES;
		while (*walker)
		{
			m_variables.insert(*walker);
			++walker;
		}
	}

	static bool			m_stringSetsSetup;
	static set<string>	m_keywords;
	static set<string>	m_preprocessorDirectives;
	static set<string>	m_macros;
	static set<string>	m_functions;
	static set<string>	m_variables;

};

bool GLSLTokenizer::GLSLTokenizer_Private::m_stringSetsSetup = false;
set<string> GLSLTokenizer::GLSLTokenizer_Private::m_preprocessorDirectives;
set<string> GLSLTokenizer::GLSLTokenizer_Private::m_macros;
set<string> GLSLTokenizer::GLSLTokenizer_Private::m_keywords;
set<string> GLSLTokenizer::GLSLTokenizer_Private::m_functions;
set<string> GLSLTokenizer::GLSLTokenizer_Private::m_variables;


// -----------------------------------------------------------------------------

GLSLTokenizer::GLSLTokenizer() :
	m_this(new GLSLTokenizer_Private)
{
}

// -----------------------------------------------------------------------------

GLSLTokenizer::~GLSLTokenizer()
{
	delete(m_this);
}

// -----------------------------------------------------------------------------

vector<GLSLToken> GLSLTokenizer::tokenize(const string & text, bool inBlockComment)
{
	vector<GLSLToken> result;

	m_this->reset(text);

	do
	{
		result.push_back(m_this->getNextToken(inBlockComment));
		inBlockComment = result.back().type() == GLSLToken::BLOCK_COMMENT;
	} while (result.back().type() != GLSLToken::END_OF_FILE);

	// END_OF_FILE Token nicht zur�ckgeben
	result.pop_back();
	return result;
}
