/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

// -----------------------------------------------------------------------------
// INCLUDES
// -----------------------------------------------------------------------------

#include <QtGui\QMainWindow>

#include "curriculum.h"


// -----------------------------------------------------------------------------
// FORWARD DECLARATIONS
// -----------------------------------------------------------------------------

class QVBoxLayout;
class QAction;
class QMenu;
class QCloseEvent;
class QDockWidget;
class QTextEdit;
class CloseSignalDockWidget;
class TabbedWindows;
class ShaderEditor;
class GLWidget;
class ShaderUniformEditor;


// -----------------------------------------------------------------------------
// CLASS DEFINITION
// -----------------------------------------------------------------------------

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(bool & success);

protected:
    void closeEvent(QCloseEvent * e);

private:
    void createMenu();
	void openLesson(int lessonID);

	Curriculum m_curriculum;
	const LessonDefinition * m_currentLesson;

	TabbedWindows * m_tabbedWindows;

    QMenu * m_fileMenu;
	QMenu * m_viewMenu;
    QMenu * m_helpMenu;
	QMenu * m_lessonMenu;

	QAction * m_showOpengl;
	QAction * m_showOutput;
	QAction * m_showSettings;
	QAction * m_showSolution;
	QAction * m_compile;
	QAction * m_about;
	QAction * m_aboutQt;

	CloseSignalDockWidget *	m_openglWindow;
	CloseSignalDockWidget *	m_outputWindow;
	CloseSignalDockWidget *	m_settingsWindow;
	QTextEdit *				m_outputTextEdit;
	GLWidget *				m_GLWidget;
	ShaderUniformEditor *	m_shaderUniformEditor;

	const ShaderEditor * m_vertexShaderEdit;
	const ShaderEditor * m_pixelShaderEdit;
	const ShaderEditor * m_vertexShaderSolutionEdit;
	const ShaderEditor * m_pixelShaderSolutionEdit;

private slots:
	void toggleOpenglWindow(bool checked);
	void toggleOutputWindow(bool checked);
	void toggleSettingsWindow(bool checked);

	void openLessonEvent();
	void compile();
	void showSolution();
	void about();

	void processCursorPositionChanged(int para, int pos);
	void processTabChanged(int type);

	void outputWindowClosed();
	void openglWindowClosed();
	void settingsWindowClosed();
};

#endif
