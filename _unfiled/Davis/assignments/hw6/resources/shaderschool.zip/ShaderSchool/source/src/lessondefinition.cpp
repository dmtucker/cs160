/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

// -----------------------------------------------------------------------------
// INCLUDES
// -----------------------------------------------------------------------------

#include "precompiled.h"

#include "lessondefinition.h"

#include <QtCore\QFile>

using namespace std;


// -----------------------------------------------------------------------------
// PRIVATE IMPLEMENTATION
// -----------------------------------------------------------------------------

class LessonDefinitionParser: public QXmlDefaultHandler
{
public:
	// -----------------------------------------------------------------------------
	
	LessonDefinitionParser(const string & filename, LessonDefinition & lessonDefinition, bool & success) :
		m_filename(filename),
		m_lessonDefinition(lessonDefinition)
	{
		QFile file(m_filename.c_str());
		if (!file.open(QFile::ReadOnly))
		{
			cerr << __FUNCTION__ << " - Could not open \"" << m_filename << "\"" << endl;
			success = false;
			return;
		}

		QXmlInputSource source(&file);

		// Standardwerte
		m_lessonDefinition.m_backgroundColor = QColor(0, 0, 0);

		QXmlSimpleReader xmlReader;
		xmlReader.setContentHandler(this);
		if (!xmlReader.parse(source))
		{
			cerr << __FUNCTION__ << " - Parsing of \"" << m_filename << "\" failed" << endl;
			success = false;
			return;
		}

		success = true;
	}

	// -----------------------------------------------------------------------------
	
	static QString getAttributeCaseInsensitive(const QXmlAttributes & atts, QString name)
	{
		QString lowerAttributeName;
		for (int i = 0; i < atts.count(); ++i)
		{
			lowerAttributeName = atts.localName(i).toLower();
			if (lowerAttributeName == name) return atts.value(i);
		}

		return QString("");
	}

	bool startElement(const QString & namespaceURI, const QString & localName, const QString & qName, const QXmlAttributes & atts) 
	{
		string lowerName = localName.toLower().toStdString();

		if (lowerName == "lesson")
		{
			m_lessonDefinition.m_name = getAttributeCaseInsensitive(atts, "title").toStdString();
			if (m_lessonDefinition.m_name == "")
			{
				cerr << __FUNCTION__ << " - Lesson \"" << m_filename << "\" has no title" << endl;
				return false;
			}
		}
		else if (lowerName == "vertexshader")
		{
			m_lessonDefinition.m_vertexshaderFile = getAttributeCaseInsensitive(atts, "file").toStdString();
			m_lessonDefinition.m_vertexshaderSolutionFile = getAttributeCaseInsensitive(atts, "solution").toStdString();

			if (m_lessonDefinition.m_vertexshaderFile == "" || m_lessonDefinition.m_vertexshaderSolutionFile == "")
			{
				cerr << __FUNCTION__ << " - In \"" << m_filename << "\": \"vertexshader\" element has to have a \"file\" and \"solution\" attribute" << endl;
				return false;
			}
		}
		else if (lowerName == "pixelshader")
		{
			m_lessonDefinition.m_pixelshaderFile = getAttributeCaseInsensitive(atts, "file").toStdString();
			m_lessonDefinition.m_pixelshaderSolutionFile = getAttributeCaseInsensitive(atts, "solution").toStdString();

			if (m_lessonDefinition.m_pixelshaderFile == "" || m_lessonDefinition.m_pixelshaderSolutionFile == "")
			{
				cerr << __FUNCTION__ << " - In \"" << m_filename << "\": \"pixelshader\" element has to have a \"file\" and \"solution\" attribute" << endl;
				return false;
			}
		}
		else if (lowerName == "html")
		{
			m_lessonDefinition.m_htmlFile = getAttributeCaseInsensitive(atts, "file").toStdString();
			
			if (m_lessonDefinition.m_htmlFile == "")
			{
				cerr << __FUNCTION__ << " - In \"" << m_filename << "\": \"html\" element has to have a \"file\" attribute" << endl;
				return false;
			}
		}
		else if (lowerName == "background")
		{
			m_lessonDefinition.m_backgroundColor = QColor(getAttributeCaseInsensitive(atts, "color"));
		}
		else if (lowerName == "object")
		{
			QString type = getAttributeCaseInsensitive(atts, "type").toLower();
			if (type == "")
			{
				cerr << __FUNCTION__ << " - In \"" << m_filename << "\": \"object\" element has to have a \"type\" attribute" << endl;
				return false;
			}

			if (type == "nothing")
				m_lessonDefinition.m_objectType = LessonDefinition::Nothing;
			else if (type == "cube")
				m_lessonDefinition.m_objectType = LessonDefinition::Cube;
			else if (type == "sphere")
				m_lessonDefinition.m_objectType = LessonDefinition::Sphere;
			else if (type == "teapot")
				m_lessonDefinition.m_objectType = LessonDefinition::Teapot;
			else if (type == "flag")
				m_lessonDefinition.m_objectType = LessonDefinition::Flag;
			else
			{
				cerr << __FUNCTION__ << " - In \"" << m_filename << "\": \"object\" element has an invalid \"type\" attribute" << endl;
				return false;
			}

			m_lessonDefinition.m_objectSize = QVariant(getAttributeCaseInsensitive(atts, "size")).toDouble();
			m_lessonDefinition.m_objectRadius = QVariant(getAttributeCaseInsensitive(atts, "radius")).toDouble();
			m_lessonDefinition.m_objectWidth = QVariant(getAttributeCaseInsensitive(atts, "width")).toDouble();
			m_lessonDefinition.m_objectHeight = QVariant(getAttributeCaseInsensitive(atts, "height")).toDouble();
			m_lessonDefinition.m_objectSlices = QVariant(getAttributeCaseInsensitive(atts, "slices")).toInt();
			m_lessonDefinition.m_objectStacks = QVariant(getAttributeCaseInsensitive(atts, "stacks")).toInt();
		}
		else if (lowerName == "update")
		{
			bool success;
			int interval = QVariant(getAttributeCaseInsensitive(atts, "interval")).toInt(&success);
			if (success) m_lessonDefinition.m_updateInterval = interval;
		}
		else if (lowerName == "texture")
		{
			string file = getAttributeCaseInsensitive(atts, "file").toStdString();
			if (file == "")
			{
				cerr << __FUNCTION__ << " - In \"" << m_filename << "\": \"texture\" element has to have a \"file\" attribute" << endl;
				return false;
			}

			bool success;
			unsigned int unit = getAttributeCaseInsensitive(atts, "unit").toUInt(&success);
			if (!success)
			{
				cerr << __FUNCTION__ << " - In \"" << m_filename << "\": \"texture\" element has to have a \"unit\" attribute containing an unsigned integer" << endl;
				return false;
			}
			if (unit >= LessonDefinition::MAX_TEXTURE_UNITS)
			{
				cerr << __FUNCTION__ << " - In \"" << m_filename << "\": \"texture\" element has to has a \"unit\" element smaller than " << LessonDefinition::MAX_TEXTURE_UNITS << endl;
				return false;
			}

			m_lessonDefinition.m_textureFiles[unit] = file;
		}

		return true;
	}

	LessonDefinition & m_lessonDefinition;
	string m_filename;
};


// -----------------------------------------------------------------------------
// CONSTRUCTION
// -----------------------------------------------------------------------------

LessonDefinition::LessonDefinition(const string & filename, bool & success) :
	m_objectType(Nothing),
	m_objectSize(-1),
	m_objectRadius(-1),
	m_objectSlices(-1),
	m_objectStacks(-1),
	m_objectWidth(-1),
	m_objectHeight(-1),
	m_updateInterval(-1)
{
	LessonDefinitionParser parser(filename, *this, success);
}

// -----------------------------------------------------------------------------

const string & LessonDefinition::textureFile(unsigned int unit) const
{
	if (unit < MAX_TEXTURE_UNITS) return m_textureFiles[unit];
	static string emptyString;
	return emptyString;
}
