/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

// -----------------------------------------------------------------------------
// INCLUDES
// -----------------------------------------------------------------------------

#include "precompiled.h"

using namespace std;

#include "glwidget.h"
#include "closesignaldockwidget.h"
#include "tabbedwindows.h"
#include "mainwindow.h"
#include "shadereditor.h"


// -----------------------------------------------------------------------------
// CONSTANTS
// -----------------------------------------------------------------------------

namespace
{
	const char *    WINDOW_TITLE = QT_TR_NOOP("ShaderSchool");
    const QSize     MINIMUM_WINDOW_SIZE(80, 60);

	const char *	VERTEX_SHADER_CAPTION = QT_TR_NOOP("Vertex Shader");
	const char *	PIXEL_SHADER_CAPTION = QT_TR_NOOP("Pixel Shader");
	const char *	VERTEX_SHADER_SOLUTION_CAPTION = QT_TR_NOOP("Vertex Shader (Musterl�sung)");
	const char *	PIXEL_SHADER_SOLUTION_CAPTION = QT_TR_NOOP("Pixel Shader (Musterl�sung)");
	const char *	ROW_STRING = QT_TR_NOOP("Zeile");
	const char *	COLUMN_STRING = QT_TR_NOOP("Spalte");

	const char *	LESSON_DIRECTORY = QT_TR_NOOP("lessons/de");
	const int		DEFAULT_LESSON_ID = 0;

	const QString	OUTPUT_FONT_NAME = "Courier New";
	const int		OUTPUT_FONT_SIZE = 10;

	const unsigned char DEFAULT_STATE[204] = {
		0x00, 0x00, 0x00, 0xFF, 0x00, 0x00, 0x00, 0x00, 0xFE, 0x00, 0x00, 0x00, 0x00, 0xFD, 0x00, 0x00, 
		0x00, 0x02, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0xBC, 0x00, 0x00, 0x02, 0x24, 0xFC, 0x02, 
		0x00, 0x00, 0x00, 0x02, 0xFB, 0x00, 0x00, 0x00, 0x18, 0x00, 0x6F, 0x00, 0x70, 0x00, 0x65, 0x00, 
		0x6E, 0x00, 0x67, 0x00, 0x6C, 0x00, 0x57, 0x00, 0x69, 0x00, 0x6E, 0x00, 0x64, 0x00, 0x6F, 0x00, 
		0x77, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x4C, 0x00, 0xFF, 
		0xFF, 0xFF, 0xFB, 0x00, 0x00, 0x00, 0x1C, 0x00, 0x73, 0x00, 0x65, 0x00, 0x74, 0x00, 0x74, 0x00, 
		0x69, 0x00, 0x6E, 0x00, 0x67, 0x00, 0x73, 0x00, 0x57, 0x00, 0x69, 0x00, 0x6E, 0x00, 0x64, 0x00, 
		0x6F, 0x00, 0x77, 0x01, 0x00, 0x00, 0x00, 0xC6, 0x00, 0x00, 0x01, 0x5E, 0x00, 0x00, 0x00, 0x4C, 
		0x00, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x03, 0xB2, 0x00, 0x00, 0x00, 0x62, 
		0xFC, 0x01, 0x00, 0x00, 0x00, 0x01, 0xFB, 0x00, 0x00, 0x00, 0x18, 0x00, 0x6F, 0x00, 0x75, 0x00, 
		0x74, 0x00, 0x70, 0x00, 0x75, 0x00, 0x74, 0x00, 0x57, 0x00, 0x69, 0x00, 0x6E, 0x00, 0x64, 0x00, 
		0x6F, 0x00, 0x77, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0xB2, 0x00, 0x00, 0x00, 0x50, 
		0x00, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x02, 0xF6, 0x00, 0x00, 0x02, 0x24
	};
}


// -----------------------------------------------------------------------------
// CONSTRUCTION
// -----------------------------------------------------------------------------

MainWindow::MainWindow(bool & success) :
	m_curriculum(tr(LESSON_DIRECTORY)),
	m_currentLesson(0),
	m_vertexShaderEdit(0),
	m_pixelShaderEdit(0),
	m_vertexShaderSolutionEdit(0),
	m_pixelShaderSolutionEdit(0)
{
    m_tabbedWindows = new TabbedWindows;
    setCentralWidget(m_tabbedWindows);
	connect(m_tabbedWindows, SIGNAL(cursorPositionChanged(int, int)), this, SLOT(processCursorPositionChanged(int, int)));
	connect(m_tabbedWindows, SIGNAL(tabChanged(int)), this, SLOT(processTabChanged(int)));

    // Dem Fenster eine Statusbar hinzuf�gen
    statusBar();

    // Das Men� erstellen
    createMenu();

	m_outputTextEdit = new QTextEdit;
	m_outputTextEdit->setReadOnly(true);
	m_outputTextEdit->setFont(QFont(OUTPUT_FONT_NAME, OUTPUT_FONT_SIZE, QFont::Normal));
	 m_outputWindow = new CloseSignalDockWidget(tr("Ausgabe"), this);
	m_outputWindow->setObjectName("outputWindow");
	m_outputWindow->setWidget(m_outputTextEdit);
	addDockWidget(Qt::BottomDockWidgetArea, m_outputWindow);
	connect(m_outputWindow, SIGNAL(closed()), this, SLOT(outputWindowClosed()));

	m_openglWindow = new CloseSignalDockWidget(tr("OpenGL"), this);
	m_openglWindow->setObjectName("openglWindow");
	m_GLWidget = new GLWidget;
	if (!m_GLWidget)
	{
		QMessageBox::critical(this, tr(WINDOW_TITLE), tr("OpenGL-Initialisierung fehlgeschlagen!"));
		success = false;
		return;
	}
	m_openglWindow->setWidget(m_GLWidget);
	addDockWidget(Qt::RightDockWidgetArea, m_openglWindow);
	connect(m_openglWindow, SIGNAL(closed()), this, SLOT(openglWindowClosed()));
	connect(m_GLWidget, SIGNAL(compilerOutput(QString)), m_outputTextEdit, SLOT(insertPlainText(const QString &)));
	if (!m_GLWidget->shaderSupported())
	{
		QMessageBox::critical(this, tr(WINDOW_TITLE), tr("Ihre Grapihkkarte unterst�tzt die ben�tigten OpenGL Extensions nicht.\n"
													 "Das Problem kann eventuell durch die Installation des neuesten Graphiktreibers behoben werden."));
		success = false;
		return;
	}

	m_settingsWindow = new CloseSignalDockWidget(tr("Einstellungen"), this);
	m_settingsWindow->setObjectName("settingsWindow");
	/*
	m_shaderUniformEditor = new ShaderUniformEditor;
	connect(m_GLWidget, SIGNAL(newUniform(const ShaderUniform *)), m_shaderUniformEditor, SLOT(handleNewUniform(const ShaderUniform *)));
	connect(m_GLWidget, SIGNAL(deleteUniform(const ShaderUniform *)), m_shaderUniformEditor, SLOT(handleDeleteUniform(const ShaderUniform *)));
	m_settingsWindow->setWidget(m_shaderUniformEditor);
	*/
	m_settingsWindow->setWidget(new QWidget);
	addDockWidget(Qt::RightDockWidgetArea, m_settingsWindow);
	connect(m_settingsWindow, SIGNAL(closed()), this, SLOT(settingsWindowClosed()));

	// Fenster initialisieren
    setWindowTitle(tr(WINDOW_TITLE));
    setMinimumSize(MINIMUM_WINDOW_SIZE);
	showMaximized();

	QSize minimumSize = m_openglWindow->minimumSize();
	QSize maximumSize = m_openglWindow->maximumSize();
	m_openglWindow->setMinimumSize(300, 300);
	m_openglWindow->setMaximumSize(300, 300);
	m_openglWindow->setMinimumSize(minimumSize);
	m_openglWindow->setMaximumSize(maximumSize);

	QByteArray state(reinterpret_cast<const char *>(DEFAULT_STATE), sizeof(DEFAULT_STATE) / sizeof(DEFAULT_STATE[0]));
	restoreState(state);

	if (m_curriculum.count() == 0)
	{
		QMessageBox::critical(this, tr(WINDOW_TITLE), tr("Es wurden keine Lektionen gefunden."));
		success = false;
		return;
	}

	openLesson(DEFAULT_LESSON_ID);

	success = true;
}

// -----------------------------------------------------------------------------

void MainWindow::createMenu()
{
    m_fileMenu = menuBar()->addMenu(tr("&Datei"));

	m_compile = m_fileMenu->addAction(tr("Shader &compilieren"));
	m_compile->setShortcut(QString("F5"));
	m_compile->setIcon(QIcon(":/compile.png"));
	connect(m_compile, SIGNAL(triggered()), this, SLOT(compile()));

	m_showSolution = m_fileMenu->addAction(tr("&Musterl�sung anzeigen"));
	m_showSolution->setCheckable(true);
	m_showSolution->setChecked(false);
	m_showSolution->setIcon(QIcon(":/solution.png"));
	connect(m_showSolution, SIGNAL(triggered()), this, SLOT(showSolution()));

	m_fileMenu->addSeparator();

    QAction * beenden = m_fileMenu->addAction(tr("&Beenden"));
    connect(beenden, SIGNAL(triggered()), this, SLOT(close()));

	m_lessonMenu = menuBar()->addMenu(tr("&Lektionen"));
	for (int i = 0; i < m_curriculum.count(); ++i)
	{
		QString lessonName = m_curriculum.lessonDefinition(i).name().c_str();
		QAction * openLesson = m_lessonMenu->addAction(lessonName);
		openLesson->setData(i);
		connect(openLesson, SIGNAL(triggered()), this, SLOT(openLessonEvent()));
	}

	m_viewMenu = menuBar()->addMenu(tr("&Ansicht"));
	m_showOpengl = m_viewMenu->addAction(tr("&OpenGL-Fenster"));
	m_showOpengl->setCheckable(true);
	m_showOpengl->setChecked(true);
	connect(m_showOpengl, SIGNAL(triggered(bool)), this, SLOT(toggleOpenglWindow(bool)));

	m_showSettings = m_viewMenu->addAction(tr("Einstellungsfenster"));
	m_showSettings->setCheckable(true);
	m_showSettings->setChecked(true);
	connect(m_showSettings, SIGNAL(triggered(bool)), this, SLOT(toggleSettingsWindow(bool)));

	m_showOutput = m_viewMenu->addAction(tr("Ausgabefenster"));
	m_showOutput->setCheckable(true);
	m_showOutput->setChecked(true);
	connect(m_showOutput, SIGNAL(triggered(bool)), this, SLOT(toggleOutputWindow(bool)));

    m_helpMenu = menuBar()->addMenu(tr("&Hilfe"));
    m_about = m_helpMenu->addAction(tr("�ber ShaderSchool..."));
	m_about->setIcon(QIcon(":/about.png"));
	connect(m_about, SIGNAL(triggered()), this, SLOT(about()));

	m_aboutQt = m_helpMenu->addAction(tr("�ber Qt..."));
	m_aboutQt->setIcon(QIcon(":/about.png"));
	connect(m_aboutQt, SIGNAL(triggered()), qApp, SLOT(aboutQt()));
}

// -----------------------------------------------------------------------------

void MainWindow::about()
{
	QMessageBox box(this);
	box.setText(tr("<center><h3>ShaderSchool</h3>"
				   "<br/>Version 1.0"
				   "<br/><br/>Copyright 2006 - 2007 Ulf Reimers & Malte Thiesen"
				   "<br/><br/>ulf.reimers@informatik.uni-hamburg.de"
				   "<br/>malte.thiesen@informatik.uni-hamburg.de"
				   "<br/><br/>This software is released under the terms of the GNU General Public Licence.<br/> "));
	box.setWindowTitle(tr("ShaderSchool"));
	box.setIcon(QMessageBox::NoIcon);
	box.exec();
}

// -----------------------------------------------------------------------------

void MainWindow::closeEvent(QCloseEvent * e)
{
    if (QMessageBox::question(this,
                              tr(WINDOW_TITLE),
                              tr("Soll ShaderSchool wirklich beendet werden?"),
                              tr("Ja"), tr("Nein"), QString(),
                              1) != 0)
    e->ignore();

	// XXX
	/*
	QByteArray state = saveState();
	ofstream file("state.bin", ofstream::binary);
	file.write(state.data(), state.size());
	*/
}

// -----------------------------------------------------------------------------

void MainWindow::toggleOpenglWindow(bool checked)
{
	if (checked)
		m_openglWindow->show();
	else
		m_openglWindow->hide();
}

// -----------------------------------------------------------------------------

void MainWindow::toggleOutputWindow(bool checked)
{
	if (checked)
		m_outputWindow->show();
	else
		m_outputWindow->hide();
}

// -----------------------------------------------------------------------------

void MainWindow::toggleSettingsWindow(bool checked)
{
	if (checked)
		m_settingsWindow->show();
	else
		m_settingsWindow->hide();
}

// -----------------------------------------------------------------------------

void MainWindow::outputWindowClosed()
{
	m_showOutput->setChecked(false);
}

// -----------------------------------------------------------------------------

void MainWindow::openglWindowClosed()
{
	m_showOpengl->setChecked(false);
}


// -----------------------------------------------------------------------------

void MainWindow::settingsWindowClosed()
{
	m_showSettings->setChecked(false);
}

// -----------------------------------------------------------------------------

void MainWindow::openLessonEvent()
{
	QAction * action = qobject_cast<QAction *>(sender());
	openLesson(action->data().toInt());
}

// -----------------------------------------------------------------------------

void MainWindow::openLesson(int lessonID)
{
	if (!m_currentLesson ||
		(&m_curriculum.lessonDefinition(lessonID) != m_currentLesson &&
		QMessageBox::question(this,
							  tr(WINDOW_TITLE),
							  tr("Soll diese Lektion wirklich geschlossen werden?"),
							  tr("Ja"), tr("Nein"), QString(), 1) == 0))
	{
		m_currentLesson = &m_curriculum.lessonDefinition(lessonID);

		QString oldPath = QDir::currentPath();
		QDir::setCurrent(tr(LESSON_DIRECTORY));

		m_tabbedWindows->hide();

		m_tabbedWindows->closeAllTabs();
		m_showSolution->setChecked(false);
		m_vertexShaderEdit = 0;
		m_pixelShaderEdit = 0;
		m_vertexShaderSolutionEdit = 0;
		m_pixelShaderSolutionEdit = 0;

		if (m_currentLesson->htmlFile().length())
		{
			QString filename = "file:";
			filename += m_currentLesson->htmlFile().c_str();
			m_tabbedWindows->addHtmlTab(filename, tr(m_currentLesson->name().c_str()));
		}

		if (m_currentLesson->vertexshaderFile().length())
		{
			m_vertexShaderEdit = m_tabbedWindows->addShaderTab(tr(VERTEX_SHADER_CAPTION), m_currentLesson->vertexshaderFile().c_str());
		}

		if (m_currentLesson->pixelshaderFile().length())
		{
			m_pixelShaderEdit = m_tabbedWindows->addShaderTab(tr(PIXEL_SHADER_CAPTION), m_currentLesson->pixelshaderFile().c_str());
		}

		m_tabbedWindows->show();

		QDir::setCurrent(oldPath);

		m_GLWidget->reset();
		m_GLWidget->setBackgroundColor(m_currentLesson->backgroundColor());
		switch (m_currentLesson->objectType())
		{
		case LessonDefinition::Cube:
			m_GLWidget->setCube(m_currentLesson->objectSize());
			break;

		case LessonDefinition::Sphere:
			m_GLWidget->setSphere(m_currentLesson->objectRadius(), m_currentLesson->objectSlices(), m_currentLesson->objectStacks());
			break;

		case LessonDefinition::Teapot:
			m_GLWidget->setTeapot(m_currentLesson->objectRadius());
			break;

		case LessonDefinition::Flag:
			m_GLWidget->setFlag(m_currentLesson->objectWidth(), m_currentLesson->objectHeight(),
								m_currentLesson->objectSlices(), m_currentLesson->objectStacks());
			break;

		default:
			m_GLWidget->setNothing();
		}

		m_GLWidget->setUpdateInterval(m_currentLesson->updateInterval());

		for (unsigned int i = 0; i < LessonDefinition::MAX_TEXTURE_UNITS; ++i)
		{
			QString file = m_currentLesson->textureFile(i).c_str();
			if (file != "") m_GLWidget->setTexture(tr(LESSON_DIRECTORY) + "/" + file, i);
		}
	}
}

// -----------------------------------------------------------------------------

void MainWindow::processCursorPositionChanged(int para, int pos)
{
	ostringstream msg;
	msg << tr(ROW_STRING).toStdString() << ": " << (para + 1) << " " << tr(COLUMN_STRING).toStdString() << ": " << (pos + 1);
	statusBar()->showMessage(msg.str().c_str());
}

// -----------------------------------------------------------------------------

void MainWindow::processTabChanged(int type)
{
	if (type == TabbedWindows::TT_HTML) statusBar()->showMessage("");
}

// -----------------------------------------------------------------------------

void MainWindow::compile()
{
	if (!m_vertexShaderEdit || !m_pixelShaderEdit)
	{
		QMessageBox::information(this, tr(WINDOW_TITLE), tr("Diese Lektion beinhaltet keine Shader!"));
	}
	else
	{
		m_outputTextEdit->clear();
		m_GLWidget->compileAndUseShaders(m_vertexShaderEdit->text(), m_pixelShaderEdit->text());

		// m_shaderUniformEditor->update();
	}
}

// -----------------------------------------------------------------------------

void MainWindow::showSolution()
{
	if (!m_vertexShaderSolutionEdit && !m_pixelShaderSolutionEdit)
	{
		if (m_currentLesson->pixelshaderSolutionFile().length() == 0 && m_currentLesson->vertexshaderSolutionFile().length() == 0)
		{
			QMessageBox::information(this, tr(WINDOW_TITLE), tr("F�r diese Lektion gibt es keine Musterl�sung!"));
			m_showSolution->setChecked(false);
		}
		else if (QMessageBox::question(this,
									tr(WINDOW_TITLE),
									tr("Soll die Musterl�sung wirklich angezeigt werden?"),
									tr("Ja"), tr("Nein"), QString(), 1) == 0)
		{
			QString oldPath = QDir::currentPath();
			QDir::setCurrent(tr(LESSON_DIRECTORY));

			m_tabbedWindows->hide();

			if (m_currentLesson->vertexshaderSolutionFile().length())
				m_vertexShaderSolutionEdit = m_tabbedWindows->addShaderTab(tr(VERTEX_SHADER_SOLUTION_CAPTION),
																		   m_currentLesson->vertexshaderSolutionFile().c_str(),
																		   true);
			if (m_currentLesson->pixelshaderSolutionFile().length())
				m_pixelShaderSolutionEdit = m_tabbedWindows->addShaderTab(tr(PIXEL_SHADER_SOLUTION_CAPTION),
																		  m_currentLesson->pixelshaderSolutionFile().c_str(),
																		  true);

			m_tabbedWindows->show();

			QDir::setCurrent(oldPath);

			m_showSolution->setChecked(true);
		}
		else
			m_showSolution->setChecked(false);
	}
	else
	{
		m_tabbedWindows->hide();

		if (m_vertexShaderSolutionEdit)
		{
			m_tabbedWindows->closeShaderTab(m_vertexShaderSolutionEdit);
			m_vertexShaderSolutionEdit = 0;
		}

		if (m_pixelShaderSolutionEdit)
		{
			m_tabbedWindows->closeShaderTab(m_pixelShaderSolutionEdit);
			m_pixelShaderSolutionEdit = 0;
		}

		m_tabbedWindows->show();

		m_showSolution->setChecked(false);
	}
}
