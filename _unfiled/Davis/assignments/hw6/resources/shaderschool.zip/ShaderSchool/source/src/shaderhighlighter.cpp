/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "precompiled.h"

#include <Qt3Support\Q3TextEdit>
#include <QtGui\QColor>

#include "shaderhighlighter.h"


// -----------------------------------------------------------------------------
// CONSTANTS
// -----------------------------------------------------------------------------

namespace
{
	class TextFormat
	{
	public:
		TextFormat(const QString & fontname, int size, int weight, const QColor & color) :
			m_fontname(fontname),
			m_size(size),
			m_weight(weight),
			m_color(color)
		{}

		QFont			font() const { return QFont(m_fontname, m_size, m_weight); }
		const QString &	fontname() const { return m_fontname; }
		const QColor &	color() const { return m_color; }
		int				size() const { return m_size; }
		int				weight() const { return m_weight; }

	private:
		QString	m_fontname;
		int		m_size;
		int		m_weight;
		QColor	m_color;
	};


	const QString		FONT_NAME("Courier New");
	const int			FONT_SIZE = 10;

	// Font f�r den Vortrag:
	// const QString		FONT_NAME("Arial");
	// const int			FONT_SIZE = 18;

	const TextFormat	DEFAULT_TEXT(FONT_NAME, FONT_SIZE, QFont::Normal, QColor(0, 0, 0));
	const TextFormat	COMMENT_TEXT(FONT_NAME, FONT_SIZE, QFont::Normal, QColor(0, 128, 0));
	const TextFormat	PREPROCESSOR_DIRECTIVE_TEXT(FONT_NAME, FONT_SIZE, QFont::Normal, QColor(136, 0, 0));
	const TextFormat	KEYWORD_TEXT(FONT_NAME, FONT_SIZE, QFont::Bold, QColor(0, 0, 200));
	const TextFormat	FUNCTION_TEXT(FONT_NAME, FONT_SIZE, QFont::Bold, QColor(136, 0, 0));
	const TextFormat	VARIABLE_TEXT(FONT_NAME, FONT_SIZE, QFont::Bold, QColor(0, 0, 0));
	const TextFormat	MACRO_TEXT(FONT_NAME, FONT_SIZE, QFont::Bold, QColor(160, 0, 160));
}


// -----------------------------------------------------------------------------

ShaderHighlighter::ShaderHighlighter(Q3TextEdit * textEdit) :
	Q3SyntaxHighlighter(textEdit)
{}


// -----------------------------------------------------------------------------

QFont ShaderHighlighter::defaultFont() const
{
	return DEFAULT_TEXT.font();
}

// -----------------------------------------------------------------------------

int ShaderHighlighter::highlightParagraph(const QString &text_qt, int endStateOfLastPara)
{
	using namespace std;

	string text = text_qt.toStdString();

	vector<GLSLToken> tokens = tokenizer.tokenize(text, endStateOfLastPara == 1);

	setFormat(0, text_qt.length(), DEFAULT_TEXT.font(), DEFAULT_TEXT.color());
	
	vector<GLSLToken>::const_iterator iter = tokens.begin();
	while (iter != tokens.end())
	{
		int start = (*iter).start() - text.begin();
		int count = (*iter).end() - (*iter).start();

		switch ((*iter).type())
		{
		case GLSLToken::LINE_COMMENT:
		case GLSLToken::BLOCK_COMMENT:
		case GLSLToken::BLOCK_COMMENT_END:
			setFormat(start, count, COMMENT_TEXT.font(), COMMENT_TEXT.color());
			break;

		case GLSLToken::PREPROCESSOR_DIRECTIVE:
			setFormat(start, count, PREPROCESSOR_DIRECTIVE_TEXT.font(), PREPROCESSOR_DIRECTIVE_TEXT.color());
			break;

		case GLSLToken::MACRO:
			setFormat(start, count, MACRO_TEXT.font(), MACRO_TEXT.color());
			break;

		case GLSLToken::KEYWORD:
			setFormat(start, count, KEYWORD_TEXT.font(), KEYWORD_TEXT.color());
			break;

		case GLSLToken::FUNCTION:
			setFormat(start, count, FUNCTION_TEXT.font(), FUNCTION_TEXT.color());
			break;

		case GLSLToken::VARIABLE:
			setFormat(start, count, VARIABLE_TEXT.font(), VARIABLE_TEXT.color());
			break;
		}

		++iter;
	}

	return tokens.back().type() == GLSLToken::BLOCK_COMMENT ? 1 : 0;
}
