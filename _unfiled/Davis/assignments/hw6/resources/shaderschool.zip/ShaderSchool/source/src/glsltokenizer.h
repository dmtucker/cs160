/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef GLSL_TOKENIZER_H
#define GLSL_TOKENIZER_H

class GLSLToken
{
public:
	enum TYPES
	{
		UNKNOWN,
		WHITESPACE,
		BLOCK_COMMENT,
		BLOCK_COMMENT_END,
		LINE_COMMENT,
		PREPROCESSOR_DIRECTIVE,
		MACRO,
		KEYWORD,
		FUNCTION,
		VARIABLE,
		END_OF_FILE,
	};

	GLSLToken(TYPES type, std::string::const_iterator start, std::string::const_iterator end) :
		m_type(type),
		m_start(start),
		m_end(end)
	{};

	TYPES						type() const { return m_type; }
	std::string::const_iterator	start() const { return m_start; }
	std::string::const_iterator	end() const { return m_end; }

private:
	TYPES						m_type;
	std::string::const_iterator	m_start;
	std::string::const_iterator	m_end;
};


class GLSLTokenizer
{
public:
	GLSLTokenizer();
	virtual ~GLSLTokenizer();

	std::vector<GLSLToken> tokenize(const std::string & text, bool inBlockComment = false);

private:
	// PIMPL-Pattern
	class GLSLTokenizer_Private;
	GLSLTokenizer_Private * m_this;
	
	// disallow copy
	GLSLTokenizer(GLSLTokenizer & source);
    GLSLTokenizer& operator=(const GLSLTokenizer & rhs);
};

#endif
