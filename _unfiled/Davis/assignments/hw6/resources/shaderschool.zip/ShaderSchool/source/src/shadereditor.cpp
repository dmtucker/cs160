/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

// -----------------------------------------------------------------------------
// INCLUDES
// -----------------------------------------------------------------------------

#include "precompiled.h"

#include "shadereditor.h"
#include "shaderhighlighter.h"


// -----------------------------------------------------------------------------
// CONSTANTS
// -----------------------------------------------------------------------------

namespace
{
	const int TAB_WIDTH	= 4;
}


// -----------------------------------------------------------------------------
// CONSTRUCTION / DESTRUCTION
// -----------------------------------------------------------------------------

ShaderEditor::ShaderEditor(QWidget * parent) :
	Q3TextEdit(parent)
{
	ShaderHighlighter * shaderHighlighter = new ShaderHighlighter(this);

	QFontMetrics fontMetrics(shaderHighlighter->defaultFont());
	setTabStopWidth(fontMetrics.width(' ') * TAB_WIDTH);
}

// -----------------------------------------------------------------------------

ShaderEditor::~ShaderEditor()
{
	// BUG ? in Qt, der Syntax-Highlighter wird nicht gel�scht, wenn der Editor gel�scht wird
	delete(syntaxHighlighter());
}


// -----------------------------------------------------------------------------

static int calcWhitespaceLength(const QString & string, int endPos = -1)
{
	if (endPos == - 1)
		endPos = string.size();
	else
		endPos = endPos < string.size() ? endPos : string.size();

	int whiteSpaceLength = 0;
	while (whiteSpaceLength < endPos &&
		   (string.at(whiteSpaceLength) == ' ' ||
		    string.at(whiteSpaceLength) == '\t')) ++whiteSpaceLength;

	return whiteSpaceLength;
}

void ShaderEditor::keyPressEvent(QKeyEvent * e)
{
	switch (e->key())
	{
	// Visual Studio Style Home-Key
	case Qt::Key_Home:
		{
			int para, index;
			getCursorPosition(&para, &index);

			QString line;
			line = text(para);

			int whiteSpaceLength = calcWhitespaceLength(line, index);

			bool shiftPressed = e->modifiers() & Qt::ShiftModifier;

			if (whiteSpaceLength == index)
				moveCursor(MoveLineStart, shiftPressed);
			else
			{
				if (shiftPressed)
				{
					if (hasSelectedText())
					{
						int paraFrom, indexFrom, paraTo, indexTo;
						getSelection(&paraFrom, &indexFrom, &paraTo, &indexTo);

						if (para == paraFrom && index == indexFrom)
							setSelection(paraTo, indexTo, para, whiteSpaceLength);
						else if (para == paraTo && index == indexTo)
							setSelection(paraFrom, indexFrom, para, whiteSpaceLength);
						else
							Q_ASSERT(false);
					}
					else
						setSelection(para, index, para, whiteSpaceLength);
				}
				else
					setCursorPosition(para, whiteSpaceLength);
			}

			e->accept();
		}
		break;
	
	// Bei Newline die Einr�ckung der vorherigen Zeile �bernehmen
	case Qt::Key_Return:
	case Qt::Key_Enter:
		{
			int para, index;
			getCursorPosition(&para, &index);

			QString prevLine = text(para);
			int whiteSpaceLength = calcWhitespaceLength(prevLine, paragraphLength(para));

			QString insertString("\n");
			insertString.append(prevLine.left(whiteSpaceLength));
			insert(insertString);

			e->accept();
		}
		break;

	default:
		Q3TextEdit::keyPressEvent(e);
	}
}
