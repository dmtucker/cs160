/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef LESSON_DEFINITION_H
#define LESSON_DEFINITION_H

// -----------------------------------------------------------------------------
// FORWARD DECLARATION
// -----------------------------------------------------------------------------

class LessonDefinitionParser;


// -----------------------------------------------------------------------------
// CLASS DEFINITION
// -----------------------------------------------------------------------------

class LessonDefinition
{
friend LessonDefinitionParser;

public:
	LessonDefinition(const std::string & filename, bool & success);

	enum OBJECT_TYPES
	{
		Nothing,
		Cube,
		Sphere,
		Teapot,
		Flag
	};

	enum
	{
		MAX_TEXTURE_UNITS = 32
	};

	const std::string & name() const { return m_name; }
	const std::string & htmlFile() const { return m_htmlFile; }
	const std::string & vertexshaderFile() const { return m_vertexshaderFile; }
	const std::string & pixelshaderFile() const { return m_pixelshaderFile; }
	const std::string & vertexshaderSolutionFile() const { return m_vertexshaderSolutionFile; }
	const std::string & pixelshaderSolutionFile() const { return m_pixelshaderSolutionFile; }
	const std::string & textureFile(unsigned int unit) const;
	QColor				backgroundColor() const { return m_backgroundColor; }
	OBJECT_TYPES		objectType() const { return m_objectType; }
	float				objectSize() const { return m_objectSize; }
	float				objectRadius() const { return m_objectRadius; }
	float				objectSlices() const { return m_objectSlices; }
	float				objectStacks() const { return m_objectStacks; }
	float				objectWidth() const { return m_objectWidth; }
	float				objectHeight() const { return m_objectHeight; }
	int					updateInterval() const { return m_updateInterval; }

	bool operator<(const LessonDefinition & other) const { return m_name < other.m_name; }

private:
	std::string		m_name;
	std::string		m_htmlFile;
	std::string		m_vertexshaderFile;
	std::string		m_pixelshaderFile;
	std::string		m_vertexshaderSolutionFile;
	std::string		m_pixelshaderSolutionFile;
	std::string		m_textureFiles[MAX_TEXTURE_UNITS];
	QColor			m_backgroundColor;
	OBJECT_TYPES	m_objectType;
	float			m_objectSize;
	float			m_objectRadius;
	float			m_objectWidth;
	float			m_objectHeight;
	int				m_objectSlices;
	int				m_objectStacks;
	int				m_updateInterval;
};

#endif
