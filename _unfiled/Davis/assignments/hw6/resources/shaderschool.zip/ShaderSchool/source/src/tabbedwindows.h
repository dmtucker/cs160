/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef TABBEDWINDOWS_H
#define TABBEDWINDOWS_H

// -----------------------------------------------------------------------------
// INCLUDES
// -----------------------------------------------------------------------------

#include <QtGui\QWidget>


// -----------------------------------------------------------------------------
// FORWARD DECLARATIONS
// -----------------------------------------------------------------------------

class QTabWidget;
class ShaderEditor;


// -----------------------------------------------------------------------------
// CLASS DEFINITION
// -----------------------------------------------------------------------------

class TabbedWindows : public QWidget
{
    Q_OBJECT

public:
	enum TAB_TYPES
	{
		TT_SHADER,
		TT_HTML,
	};

    TabbedWindows(QWidget * parent = 0);

signals:
	void tabChanged(int type);
	void cursorPositionChanged(int para, int pos);

public slots:
    void addHtmlTab(const QString & source, const QString & title);
    const ShaderEditor * addShaderTab(const QString & title, const QString & filename = "", bool readOnly = false);

	void closeShaderTab(const ShaderEditor * shaderEditor);

	void processCurrentTabChanged(int index);
	void processCursorPositionChanged(int para, int pos);

    void closeAllTabs();

private:
    QTabWidget * m_tab;
};

#endif
