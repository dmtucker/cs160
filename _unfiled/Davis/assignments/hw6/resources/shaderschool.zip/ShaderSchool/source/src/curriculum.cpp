/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

// -----------------------------------------------------------------------------
// INCLUDES
// -----------------------------------------------------------------------------

#include "precompiled.h"

#include "curriculum.h"

using namespace std;


// -----------------------------------------------------------------------------
// CONSTRUCTION
// -----------------------------------------------------------------------------

Curriculum::Curriculum(const QString & lessonDirectory)
{
	QDir dir(QDir::currentPath());
	dir.cd(lessonDirectory);
	QStringList files = dir.entryList();

	for (int i = 0; i < files.count(); ++i)
	{
		if (files.at(i).endsWith(".xml", Qt::CaseInsensitive))
		{
			string filename = dir.path().toStdString();
			filename += "/";
			filename += files.at(i).toStdString();

			bool success;
			LessonDefinition lessonDefinition(filename, success);
			if (!success)
			{
				cerr << __FUNCTION__ << " - Lesson \"" << filename << "\" is skipped" << endl;
			}
			else
			{
				m_lessons.push_back(lessonDefinition);
			}
		}
	}

	sort(m_lessons.begin(), m_lessons.end());
}
