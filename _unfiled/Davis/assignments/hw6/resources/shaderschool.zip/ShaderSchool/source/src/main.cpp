/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "precompiled.h"

#include "mainwindow.h"


QString getTranslationFilename(int argc, char *argv[])
{
	// Die Spracheinstellung kann per Kommandozeile gesetzt werden
	// Die Optionen sind:
	// -en
	// -de
	//
	// Wenn keine Sprache angegeben wurde, wird die Spracheinstellung des Betriebssystems als Grundlage genommen.
	// Bei deutscher Sprache wird Deutsch verwendet, ansonsten Englisch.

	int language = 0;

	for (int i = 1; i < argc; ++i)
	{
		QString curParam(argv[i]);
		curParam.toLower();
		if (curParam == "-en")
		{
			language = QLocale::English;
			break;
		}
		if (curParam == "-de")
		{
			language = QLocale::German;
			break;
		}
	}
	if (language == 0) language = QLocale::system().language();

	if (language == QLocale::German)
		return QString(":/shaderschool_de.qm");
	else
		return QString(":/shaderschool_en.qm");
}

int main(int argc, char *argv[])
{
	Q_INIT_RESOURCE(ShaderSchool);

    QApplication app(argc, argv);

	QTranslator translator;
	translator.load(getTranslationFilename(argc, argv));
	app.installTranslator(&translator);

	bool success;
    MainWindow window(success);
	if (success)
	{
		window.show();
		return app.exec();
	}
	else
		return 1;
}

#ifdef _WIN32 

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR Args, int WinMode)
{
	char * argv[2];
	argv[0] = 0;
	argv[1] = Args;
	return main(strlen(Args) == 0 ? 1 : 2, argv);
}

#endif
