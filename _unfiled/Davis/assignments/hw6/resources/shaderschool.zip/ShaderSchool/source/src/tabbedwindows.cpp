/*
	ShaderSchool
    Copyright (C) 2006 - 2007 Ulf Reimers & Malte Thiesen

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

// -----------------------------------------------------------------------------
// INCLUDES
// -----------------------------------------------------------------------------

#include "precompiled.h"

#include "tabbedwindows.h"
#include "shadereditor.h"

using namespace std;


// -----------------------------------------------------------------------------
// CONSTANTS
// -----------------------------------------------------------------------------

namespace
{
	
}


// -----------------------------------------------------------------------------
// CONSTRUCTION
// -----------------------------------------------------------------------------

TabbedWindows::TabbedWindows(QWidget * parent) :
    QWidget(parent)
{
	QBoxLayout * boxLayout = new QBoxLayout(QBoxLayout::LeftToRight, this);
	boxLayout->setSpacing(0);
	boxLayout->setMargin(0);

    m_tab = new QTabWidget(this);
    boxLayout->addWidget(m_tab);
	connect(m_tab, SIGNAL(currentChanged(int)), this, SLOT(processCurrentTabChanged(int)));
}

// -----------------------------------------------------------------------------

void TabbedWindows::addHtmlTab(const QString & source, const QString & title)
{
    QTextBrowser * browser = new QTextBrowser;
    browser->setSource(source);
    m_tab->addTab(browser, title);
}

// -----------------------------------------------------------------------------

const ShaderEditor * TabbedWindows::addShaderTab(const QString & title, const QString & filename, bool readOnly)
{
    ShaderEditor * shaderEditor = new ShaderEditor;
	m_tab->addTab(shaderEditor, title);
	shaderEditor->setReadOnly(readOnly);
	
	if (filename.length())
	{
		QFile file(filename);
		if (file.open(QFile::ReadOnly))
		{
			QByteArray data = file.readAll();
			if (!data.size())
			{
				cerr << __FUNCTION__ << " : \"" << filename.toStdString() << "\" is empty or could not be read" << endl;
			}
			else
			{
				QString content(data);
				shaderEditor->append(content);
				connect(shaderEditor, SIGNAL(cursorPositionChanged(int, int)), this, SLOT(processCursorPositionChanged(int, int)));
			}
		}
		else
			cerr << __FUNCTION__ << " : Unable to open \"" << filename.toStdString() << "\"" << endl;
	}

	return shaderEditor;
}

// -----------------------------------------------------------------------------

void TabbedWindows::closeAllTabs()
{
    while (m_tab->count())
    {
        QTimer::singleShot(0, m_tab->widget(m_tab->count() - 1), SLOT(deleteLater()));
		delete(m_tab->widget(m_tab->count() - 1));
    }
}

// -----------------------------------------------------------------------------

void TabbedWindows::closeShaderTab(const ShaderEditor * shaderEditor)
{
	for (int i = 0; i < m_tab->count(); ++i)
	{
		if (m_tab->widget(i) == shaderEditor)
		{
			QTimer::singleShot(0, m_tab->widget(i), SLOT(deleteLater()));
			delete(m_tab->widget(i));
		}
	}
}

// -----------------------------------------------------------------------------

void TabbedWindows::processCursorPositionChanged(int para, int pos)
{
	emit cursorPositionChanged(para, pos);
}

// -----------------------------------------------------------------------------

void TabbedWindows::processCurrentTabChanged(int index)
{
	ShaderEditor * shaderEditor;
	if (shaderEditor = qobject_cast<ShaderEditor *>(m_tab->widget(index)))
	{
		emit tabChanged(TT_SHADER);

		int para, pos;
		shaderEditor->getCursorPosition(&para, &pos);
		emit cursorPositionChanged(para, pos);
	}
	else
	{
		emit tabChanged(TT_HTML);
	}
}
