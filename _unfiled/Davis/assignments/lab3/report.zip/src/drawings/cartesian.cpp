#define GRID_DELTA    20 // world units per grid unit
#define GRID_COLOR    BASIC_BLACK
#define GRID_COLOR_Q1 GRID_COLOR
#define GRID_COLOR_Q2 GRID_COLOR
#define GRID_COLOR_Q3 GRID_COLOR
#define GRID_COLOR_Q4 GRID_COLOR
#define GRID_LENGTH   FAR/2

bool   axis = false, grid = true;
GLuint axisVAO = 0,  gridVAO = 0;


void initAxis ( ) {
    
    static GLuint axisVBO = 0;
    
    static bool uninitialized = true;
    if (uninitialized) {
        
        const GLfloat l = GRID_LENGTH;
        vec4 axisXYZW[12] = {
            AXIS_ORIGIN,vec4( l, 0, 0, 1), // +x
            AXIS_ORIGIN,vec4(-l, 0, 0, 1), // -x
            AXIS_ORIGIN,vec4( 0, l, 0, 1), // +y
            AXIS_ORIGIN,vec4( 0,-l, 0, 1), // -y
            AXIS_ORIGIN,vec4( 0, 0, l, 1), // +z
            AXIS_ORIGIN,vec4( 0, 0,-l, 1)  // -z
        };
        vec4 axisRGBA[12] = {
            palette[BASIC_RED]  ,palette[BASIC_WHITE], // +x
            palette[BASIC_RED]  ,palette[BASIC_BLACK], // -x
            palette[BASIC_GREEN],palette[BASIC_WHITE], // +y
            palette[BASIC_GREEN],palette[BASIC_BLACK], // -y
            palette[BASIC_BLUE] ,palette[BASIC_WHITE], // +z
            palette[BASIC_BLUE] ,palette[BASIC_BLACK]  // -z
        };
        
        currentShader(darkShader);
        
        glGenBuffers(1,&axisVBO);
        glBindBuffer(GL_ARRAY_BUFFER,axisVBO);
        glBufferData(GL_ARRAY_BUFFER,sizeof(axisXYZW)+sizeof(axisRGBA),NULL,GL_STATIC_DRAW);
        glBufferSubData(GL_ARRAY_BUFFER,0               ,sizeof(axisXYZW),axisXYZW);
        glBufferSubData(GL_ARRAY_BUFFER,sizeof(axisXYZW),sizeof(axisRGBA),axisRGBA);
        checkGL(__FILE__,__LINE__);
        
        glGenVertexArrays(1,&axisVAO);
        glBindVertexArray(axisVAO);
        glEnableVertexAttribArray(DSVposition);
        glEnableVertexAttribArray(DSVcolor);
        glVertexAttribPointer(DSVposition,4,GL_FLOAT,GL_FALSE,0,VOID(0));
        glVertexAttribPointer(DSVcolor   ,4,GL_FLOAT,GL_FALSE,0,VOID(sizeof(axisXYZW)));
        checkGL(__FILE__,__LINE__);
    
        uninitialized = false;
    }
    else {
        
        glBindVertexArray(0);
        glDeleteVertexArrays(1,&axisVAO);
        glDeleteBuffers     (1,&axisVBO);
        checkGL(__FILE__,__LINE__);
        
        uninitialized = true;
    }
}


void initGrid ( ) {
    
    static GLuint gridVBO = 0;
    
    static bool uninitialized = true;
    if (uninitialized) {
        
        const GLfloat l = GRID_LENGTH;
        GLint gridNaturals = l/GRID_DELTA;
        vec4 gridXYZW[gridNaturals*16], gridRGBA[gridNaturals*16];
        
        int gridI = 0;
        for (int i=0; i < gridNaturals ;++i) {
            
            int offset = i*GRID_DELTA;
            if (offset > FAR) offset = FAR;
            
            // +X, -Z
            gridXYZW[gridI] = vec4( offset,0, 0,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q1];
                   ++gridI;
            gridXYZW[gridI] = vec4( offset,0,-l,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q1];
                   ++gridI;
            
            // -Z, +X
            gridXYZW[gridI] = vec4( 0,0,-offset,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q1];
                   ++gridI;
            gridXYZW[gridI] = vec4( l,0,-offset,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q1];
                   ++gridI;
            
            // -X, -Z
            gridXYZW[gridI] = vec4(-offset,0, 0,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q2];
                   ++gridI;
            gridXYZW[gridI] = vec4(-offset,0,-l,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q2];
                   ++gridI;
            
            // -Z, -X
            gridXYZW[gridI] = vec4( 0,0,-offset,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q2];
                   ++gridI;
            gridXYZW[gridI] = vec4(-l,0,-offset,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q2];
                   ++gridI;
            
            // -X, +Z
            gridXYZW[gridI] = vec4(-offset,0, 0,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q3];
                   ++gridI;
            gridXYZW[gridI] = vec4(-offset,0, l,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q3];
                   ++gridI;
            
            // +Z, -X
            gridXYZW[gridI] = vec4( 0,0, offset,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q3];
                   ++gridI;
            gridXYZW[gridI] = vec4(-l,0, offset,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q3];
                   ++gridI;
            
            // +X, +Z
            gridXYZW[gridI] = vec4( offset,0, 0,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q4];
                   ++gridI;
            gridXYZW[gridI] = vec4( offset,0, l,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q4];
                   ++gridI;
            
            // +Z, +X
            gridXYZW[gridI] = vec4( 0,0, offset,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q4];
                   ++gridI;
            gridXYZW[gridI] = vec4( l,0, offset,1);
            gridRGBA[gridI] = palette[GRID_COLOR_Q4];
                   ++gridI;
        }
        
        currentShader(darkShader);
        
        glGenBuffers(1,&gridVBO);
        glBindBuffer(GL_ARRAY_BUFFER,gridVBO);
        glBufferData(   GL_ARRAY_BUFFER,sizeof(gridXYZW)+sizeof(gridRGBA),NULL,GL_STATIC_DRAW);
        glBufferSubData(GL_ARRAY_BUFFER,0               ,sizeof(gridXYZW),gridXYZW);
        glBufferSubData(GL_ARRAY_BUFFER,sizeof(gridXYZW),sizeof(gridRGBA),gridRGBA);
        checkGL(__FILE__,__LINE__);
        
        glGenVertexArrays(1,&gridVAO);
        glBindVertexArray(gridVAO);
        glEnableVertexAttribArray(DSVposition);
        glEnableVertexAttribArray(DSVcolor);
        glVertexAttribPointer(DSVposition,4,GL_FLOAT,GL_FALSE,0,VOID(0));
        glVertexAttribPointer(DSVcolor   ,4,GL_FLOAT,GL_FALSE,0,VOID(sizeof(gridXYZW)));
        checkGL(__FILE__,__LINE__);
        
        uninitialized = false;
    }
    else {
        
        glBindVertexArray(0);
        glDeleteVertexArrays(1,&gridVAO);
        glDeleteBuffers     (1,&gridVBO);
        checkGL(__FILE__,__LINE__);
        
        uninitialized = true;
    }
}


void initCartesian ( ) {
    static bool uninitialized = true;
    if (uninitialized) {
        
        initAxis();
        initGrid();
        
        uninitialized = false;
    }
    else {
        
        initGrid();
        initAxis();
        
        uninitialized = true;
    }
}


void drawCartesian ( ) {
    
    currentShader(darkShader);
    
    if (axis) {
        glBindVertexArray(axisVAO);
        glUniformMatrix4fv(DSmodel,1,GL_FALSE,value_ptr(mat4()));
        glDrawArrays(GL_LINES,0,12);
    }
    
    if (grid) {
        glBindVertexArray(gridVAO);
        glUniformMatrix4fv(DSmodel,1,GL_FALSE,value_ptr(mat4()));
        const int adjust = (axis) ? 1 : 0;
        glDrawArrays(GL_LINES,16*adjust,16*((GRID_LENGTH/GRID_DELTA)-adjust));
    }
}
