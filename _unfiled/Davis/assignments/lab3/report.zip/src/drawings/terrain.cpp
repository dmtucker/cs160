#define TERRAIN_COLOR CSS_WHITE

const unsigned int terrainTriangles = 512*512*2; //XXX

GLuint terrainVAO   = 0;
mat4   terrainModel = mat4();

vec4 Tpoints  [terrainTriangles*3],
     Tcolors  [terrainTriangles*3],
     Tnormals [terrainTriangles*3];

vec2 Ttextures[terrainTriangles*3];


double linear_map ( const double       x ,
                    const double     min ,
                    const double     max ,
                    const double new_min ,
                    const double new_max ) {
    return (((x-min)*(new_max-new_min))/(max-min))+new_min;
}

double percentage ( double x , double min , double max ) { return linear_map(x,min,max,0,1); }


void initTerrain ( ) {
    
    GLuint terrainVBO = 0;
    
    static bool uninitialized = true;
    if (uninitialized) {
        
//        vec4 Tpoints[terrainTriangles*3], Tnormals[terrainTriangles*3]; //XXX Segmentation fault???
        
        double hDelta = (texture.height/terrain.height)/100.0;
        double wDelta = (texture.width /terrain.width) /100.0;
        
        GLuint p = 0;
        for (int i=1; i <= terrain.height ;++i) {
            
            for (int j=1; j <= terrain.width ;++j) {
                
                vec4 a, b, c, normal;
                
                a = Tpoints[p  ] = vec4(j-1,RED(PIXEL(terrain,i-1,j-1)),i-1,1); // upper left
                b = Tpoints[p+1] = vec4(j-1,RED(PIXEL(terrain,i  ,j-1)),i  ,1); // lower left
                c = Tpoints[p+2] = vec4(j  ,RED(PIXEL(terrain,i  ,j  )),i  ,1); // lower right
                
                Tcolors[p+2] = Tcolors[p+1] = Tcolors[p] = palette[TERRAIN_COLOR];
                
                GLfloat aa = percentage(i-1,0,texture.height);
                GLfloat bb = percentage(j-1,0,texture.width);
                GLfloat cc = percentage(j  ,0,texture.width);
                GLfloat dd = percentage(i  ,0,texture.height);
printf("%f %f %f %f\n",aa,bb,cc,dd); //XXX
                
                Ttextures[p  ] = vec2(bb,aa);
                Ttextures[p+1] = vec2(bb,dd);
                Ttextures[p+2] = vec2(cc,dd);
                
                normal = vec4(normalize(cross(vec3(b-a),vec3(c-b))),0);
                Tnormals [p+2] = Tnormals[p+1] = Tnormals[p] = normal;
                
                p += 3;
                
                a = Tpoints[p  ] = vec4(j-1,RED(PIXEL(terrain,i-1,j-1)),i-1,1); // upper left
                b = Tpoints[p+1] = vec4(j  ,RED(PIXEL(terrain,i  ,j  )),i  ,1); // lower right
                c = Tpoints[p+2] = vec4(j  ,RED(PIXEL(terrain,i-1,j  )),i-1,1); // upper right
                
                Tcolors[p+2] = Tcolors[p+1] = Tcolors[p] = palette[TERRAIN_COLOR];
                
                Ttextures[p  ] = vec2(aa,bb);
                Ttextures[p+1] = vec2(dd,cc);
                Ttextures[p+2] = vec2(aa,cc);
                
                normal = vec4(normalize(cross(vec3(b-a),vec3(c-b))),0);
                Tnormals[p+2] = Tnormals[p+1] = Tnormals[p] = normal;
                
                p += 3;
            }
            
        }
        
        currentShader(standardShader);
        
        glGenBuffers(1,&terrainVBO);
        glBindBuffer(GL_ARRAY_BUFFER,terrainVBO);
        glBufferData(
            GL_ARRAY_BUFFER,
            sizeof(Tpoints)+sizeof(Tcolors)+sizeof(Tnormals)+sizeof(Ttextures),
            NULL,
            GL_STATIC_DRAW
        );
        size_t offset = 0;
        glBufferSubData(GL_ARRAY_BUFFER,offset,sizeof(Tpoints)  ,Tpoints);   offset += sizeof(Tpoints);
        glBufferSubData(GL_ARRAY_BUFFER,offset,sizeof(Tcolors)  ,Tcolors);   offset += sizeof(Tcolors);
        glBufferSubData(GL_ARRAY_BUFFER,offset,sizeof(Tnormals) ,Tnormals);  offset += sizeof(Tnormals);
        glBufferSubData(GL_ARRAY_BUFFER,offset,sizeof(Ttextures),Ttextures); offset += sizeof(Ttextures);
        checkGL(__FILE__,__LINE__);
        
        offset = 0;
        glGenVertexArrays(1,&terrainVAO);
        glBindVertexArray(terrainVAO);
        glEnableVertexAttribArray(SSVposition);
        glEnableVertexAttribArray(SSVcolor);
        glEnableVertexAttribArray(SSVnormal);
        glEnableVertexAttribArray(SSTcoordinate);
        glVertexAttribPointer(SSVposition  ,4,GL_FLOAT,GL_FALSE,0,VOID(offset)); offset += sizeof(Tpoints);
        glVertexAttribPointer(SSVcolor     ,4,GL_FLOAT,GL_FALSE,0,VOID(offset)); offset += sizeof(Tcolors);
        glVertexAttribPointer(SSVnormal    ,4,GL_FLOAT,GL_FALSE,0,VOID(offset)); offset += sizeof(Tnormals);
        glVertexAttribPointer(SSTcoordinate,2,GL_FLOAT,GL_FALSE,0,VOID(offset)); offset += sizeof(Ttextures);
        
        uninitialized = false;
    }
    else {
        
        glBindVertexArray(0);
        glDeleteVertexArrays(1,&terrainVAO);
        glDeleteBuffers     (1,&terrainVBO);
        checkGL(__FILE__,__LINE__);
        
        uninitialized = true;
    }
}


void drawTerrain ( ) {
    
    currentShader(standardShader);
    glBindVertexArray(terrainVAO);
    glUniformMatrix4fv(SSmodel,1,GL_FALSE,value_ptr(terrainModel));
    glUniform1i(SSTmap,0); //XXX
    
    const GLfloat material_shininess = 100;
    const vec4    material_ambient   = vec4(1.0,0.0,1.0,1.0),
                  material_diffuse   = vec4(1.0,0.8,0.0,1.0),
                  material_specular  = vec4(1.0,0.8,0.0,1.0);
    
    glUniform1f (SSMshininess,  material_shininess);
    glUniform4fv(SSMambient  ,1,value_ptr(material_ambient));
    glUniform4fv(SSMdiffuse  ,1,value_ptr(material_diffuse));
    glUniform4fv(SSMspecular ,1,value_ptr(material_specular));
    
    glDrawArrays(GL_TRIANGLES,0,terrainTriangles*3);
    checkGL(__FILE__,__LINE__);
}
