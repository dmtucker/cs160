#define SPHERE_COLOR CSS_WHITE

const unsigned int sphereIterations = 4;
const unsigned int sphereTriangles  = 2*pow(4,sphereIterations+1);

GLuint sphereVAO   = 0;
mat4   sphereModel = mat4();

vec4 Spoints[sphereTriangles*3],
     Scolors[sphereTriangles*3],
    Snormals[sphereTriangles*3];

void recursiveSphereQuadrant ( const vec4 a , const vec4 b , const vec4 c , int level ) {
    if (level > 0) {
        
        vec4 m[3];
        m[0] = (a+b)/2.0;
        m[1] = (a+c)/2.0;
        m[2] = (b+c)/2.0;
        
        for (int i=0 ; i < 3 ;++i) {
            m[i] = normalize(vec4(m[i].x,m[i].y,m[i].z,0.0));
            m[i] = vec4(m[i].x,m[i].y,m[i].z,1.0);
        }
        
        recursiveSphereQuadrant(a   ,m[0],m[1],level-1);
        recursiveSphereQuadrant(m[0],b   ,m[2],level-1);
        recursiveSphereQuadrant(m[1],m[2],c   ,level-1);
        recursiveSphereQuadrant(m[0],m[2],m[1],level-1);
    }
    else {
        
        static unsigned int i = 0;
        Spoints[i] = Snormals[i] = a; Scolors[i] = palette[SPHERE_COLOR]; ++i;
        Spoints[i] = Snormals[i] = b; Scolors[i] = palette[SPHERE_COLOR]; ++i;
        Spoints[i] = Snormals[i] = c; Scolors[i] = palette[SPHERE_COLOR]; ++i;
    }
}


void initSphere ( ) {
    
    static GLuint sphereVBO = 0;
    
    static bool uninitialized = true;
    if (uninitialized) {
        
        const vec4 a = vec4( 0, 1, 0, 1);
        const vec4 b = vec4( 0, 0, 1, 1);
        const vec4 c = vec4( 1, 0, 0, 1);
        const vec4 d = vec4( 0, 0,-1, 1);
        const vec4 e = vec4(-1, 0, 0, 1);
        const vec4 f = vec4( 0,-1, 0, 1);
        recursiveSphereQuadrant(a,b,c,sphereIterations);
        recursiveSphereQuadrant(a,c,d,sphereIterations);
        recursiveSphereQuadrant(a,d,e,sphereIterations);
        recursiveSphereQuadrant(a,e,b,sphereIterations);
        recursiveSphereQuadrant(f,c,b,sphereIterations);
        recursiveSphereQuadrant(f,d,c,sphereIterations);
        recursiveSphereQuadrant(f,e,d,sphereIterations);
        recursiveSphereQuadrant(f,b,e,sphereIterations);
        
        currentShader(lightShader);
        
        glGenBuffers(1,&sphereVBO);
        glBindBuffer(GL_ARRAY_BUFFER,sphereVBO);
        glBufferData(
            GL_ARRAY_BUFFER,
            sizeof(Spoints)+sizeof(Scolors)+sizeof(Snormals),
            NULL,
            GL_STATIC_DRAW
        );
        
        size_t offset = 0;
        glBufferSubData(GL_ARRAY_BUFFER,offset,sizeof(Spoints) ,Spoints);  offset += sizeof(Spoints);
        glBufferSubData(GL_ARRAY_BUFFER,offset,sizeof(Scolors) ,Scolors);  offset += sizeof(Scolors);
        glBufferSubData(GL_ARRAY_BUFFER,offset,sizeof(Snormals),Snormals); offset += sizeof(Snormals);
        checkGL(__FILE__,__LINE__);
        
        offset = 0;
        glGenVertexArrays(1,&sphereVAO);
        glBindVertexArray(sphereVAO);
        glEnableVertexAttribArray(LSVposition);
        glEnableVertexAttribArray(LSVcolor);
        glEnableVertexAttribArray(LSVnormal);
        glVertexAttribPointer(LSVposition,4,GL_FLOAT,GL_FALSE,0,VOID(offset)); offset += sizeof(Spoints);
        glVertexAttribPointer(LSVcolor   ,4,GL_FLOAT,GL_FALSE,0,VOID(offset)); offset += sizeof(Scolors);
        glVertexAttribPointer(LSVnormal  ,4,GL_FLOAT,GL_FALSE,0,VOID(offset)); offset += sizeof(Snormals);
        checkGL(__FILE__,__LINE__);
        
        uninitialized = false;
    }
    else {
        
        glBindVertexArray(0);
        glDeleteVertexArrays(1,&sphereVAO);
        glDeleteBuffers     (1,&sphereVBO);
        checkGL(__FILE__,__LINE__);
        
        uninitialized = true;
    }
}


void drawSphere ( ) {
    
    currentShader(lightShader);
    glBindVertexArray(sphereVAO);
    glUniformMatrix4fv(LSmodel,1,GL_FALSE,value_ptr(sphereModel));
    
    // brass
//    const GLfloat material_shininess = 27.8;
//    const vec4    material_ambient   = vec4(0.33,0.22,0.03,1),
//                  material_diffuse   = vec4(0.78,0.57,0.11,1),
//                  material_specular  = vec4(0.99,0.91,0.81,1);
    
    const GLfloat material_shininess = 1;
    const vec4    material_ambient   = vec4(1,1,1,1),
                  material_diffuse   = vec4(1,1,1,1),
                  material_specular  = vec4(1,1,1,1);
    
    glUniform1f (LSMshininess,  material_shininess);
    glUniform4fv(LSMambient  ,1,value_ptr(material_ambient));
    glUniform4fv(LSMdiffuse  ,1,value_ptr(material_diffuse));
    glUniform4fv(LSMspecular ,1,value_ptr(material_specular));
    
    glDrawArrays(GL_TRIANGLES,0,sphereTriangles*3);
    checkGL(__FILE__,__LINE__);
}
