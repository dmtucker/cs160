#include "colors.h"

#define DEFAULT_W 640 // pixels
#define DEFAULT_H 480 // pixels
#define MAX_FPS    30 // fps

char title[128];
GLFWwindow * defaultWindow  = NULL;
int windowX = 0, windowY = 0, windowW = DEFAULT_W, windowH = DEFAULT_H;
unsigned long int frames = 0;

#define ASPECT_RATIO (windowW/(GLfloat) windowH)
#define FPS          (frames/glfwGetTime())

vec3 pCursor = vec3(0,0,1), vCursor = vec3(0,0,1);

GLuint basicShader  = 0, darkShader   = 0, lightShader  = 0, standardShader = 0,
       BSmodel      = 0, DSmodel      = 0, LSmodel      = 0, SSmodel        = 0,
       BSview       = 0, DSview       = 0, LSview       = 0, SSview         = 0,
       BSprojection = 0, DSprojection = 0, LSprojection = 0, SSprojection   = 0,
       BSVposition  = 0, DSVposition  = 0, LSVposition  = 0, SSVposition    = 0,
       BSVcolor     = 0, DSVcolor     = 0, LSVcolor     = 0, SSVcolor       = 0,
                                                             SSTcoordinate  = 0,
                                                             SSTmap         = 0,
                                           LSVnormal    = 0, SSVnormal      = 0,
                                           LSLposition  = 0, SSLposition    = 0,
                                           LSLambient   = 0, SSLambient     = 0,
                                           LSLdiffuse   = 0, SSLdiffuse     = 0,
                                           LSLspecular  = 0, SSLspecular    = 0,
                                           LSMshininess = 0, SSMshininess   = 0,
                                           LSMambient   = 0, SSMambient     = 0,
                                           LSMdiffuse   = 0, SSMdiffuse     = 0,
                                           LSMspecular  = 0, SSMspecular    = 0;

#define FAR        2000.0f // world units
#define PROJECTION (lens) ? perspective(lens,ASPECT_RATIO,0.1f,FAR) \
                          : ortho(-FAR/10,FAR/10,-FAR/10,FAR/10,0.1f,FAR)

#define AXIS_X      vec4(1,0,0,0)
#define AXIS_Y      vec4(0,1,0,0)
#define AXIS_Z      vec4(0,0,1,0)
#define AXIS_ORIGIN vec4(0,0,0,1)

canvas_t terrain, texture;

vec4 pLight = vec4(0,FAR,0,1),
      light_ambient  = vec4(0.2,0.2,0.2,1.0),
      light_diffuse  = vec4(1.0,1.0,1.0,1.0),
      light_specular = vec4(1.0,1.0,1.0,1.0);

bool lighting = true;

#define VERTICAL_FOV 60 // degrees

vec4 pEye   = AXIS_ORIGIN,
     pFocus = vec4(0,0,-1,1),
     vUp    = AXIS_Y;
     
GLfloat lens = VERTICAL_FOV, zoom = 1;

bool zooming = false;

bool moveL = false, lookL = false, lightL = false, // left
     moveR = false, lookR = false, lightR = false, // right
     moveU = false, lookU = false, lightU = false, // up
     moveD = false, lookD = false, lightD = false, // down
     moveB = false,                lightB = false, // back
     moveF = false,                lightF = false, // forth
     
     orbitCW  = false,
     orbitCCW = false,
     
     cull = true,
     skew = false,
     wire = false;
