#include "shader.hpp"


void initGLFW ( ) {
    static bool uninitialized = true;
    if (uninitialized) {
    
        glfwSetErrorCallback(error);
        if (not glfwInit()) {
            fputs("GLFW Initialization Error",stderr);
            exit(EXIT_FAILURE);
        }
        
        glfwDefaultWindowHints();
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR,3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR,3);
        glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT,GL_TRUE);
        glfwWindowHint(GLFW_OPENGL_DEBUG_CONTEXT,GL_TRUE); //XXX
        glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
        defaultWindow = glfwCreateWindow(DEFAULT_W,DEFAULT_H,&title[0],NULL,NULL);
        if (defaultWindow == NULL) {
            glfwTerminate();
            fputs("Window Creation Error",stderr);
            exit(EXIT_FAILURE);
        }
        glfwMakeContextCurrent(defaultWindow);

//             glfwSetWindowSizeCallback(defaultWindow,resize); // screen coordinates
        glfwSetFramebufferSizeCallback(defaultWindow,resize); // pixels
                    glfwSetKeyCallback(defaultWindow,keyboard);
            glfwSetMouseButtonCallback(defaultWindow,click);
              glfwSetCursorPosCallback(defaultWindow,hover);
                 glfwSetScrollCallback(defaultWindow,scroll);
        
        printf("GLFW v%s\n",glfwGetVersionString());
        
        uninitialized = false;
    }
    else {
        
        glfwDestroyWindow(defaultWindow);
        glfwTerminate();
        
        uninitialized = true;
    }
}


void initGLEW ( ) {
    static bool uninitialized = true;
    if (uninitialized) {
        
        glewExperimental = GL_TRUE; //XXX < v4.0
        GLenum status = glewInit();
        if (status != GLEW_OK) {
            fprintf(
                stderr,
                "GLEW Initialization Error (%s).\n",
                glewGetErrorString(status)
            );
            exit(EXIT_FAILURE);
        }
        else (void) glGetError();
        printf("GLEW v%s\n",glewGetString(GLEW_VERSION));
        
        uninitialized = false;
    }
    else uninitialized = true;
}


void initGL ( ) {
    
    GLuint defaultTexture = 0;
    
    static bool uninitialized = true;
    if (uninitialized) {
        
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        checkGL(__FILE__,__LINE__);
        
        glClearColor(0.1,0.1,0.1,1);
        glClearDepth(1);
        
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LESS);
        checkGL(__FILE__,__LINE__);
        
        glEnable(GL_CULL_FACE);
        glCullFace(GL_BACK);
        glFrontFace(GL_CCW);
        checkGL(__FILE__,__LINE__);
        
        
        basicShader = shaderProgram(
            "src/shaders/vertex_basic.glsl",
            "src/shaders/fragment_basic.glsl"
        );
        currentShader(basicShader);
        checkGL(__FILE__,__LINE__);
        
        BSmodel      = glGetUniformLocation(basicShader,"model");
        BSview       = glGetUniformLocation(basicShader,"view");
        BSprojection = glGetUniformLocation(basicShader,"projection");
        BSVposition  = glGetAttribLocation( basicShader,"position");
        BSVcolor     = glGetUniformLocation(basicShader,"color");
        checkGL(__FILE__,__LINE__);
        
//        printf("BSmodel      (%d)\n",BSmodel);
//        printf("BSview       (%d)\n",BSview);
//        printf("BSprojection (%d)\n",BSprojection);
//        printf("BSVposition  (%d)\n",BSVposition);
//        printf("BSVcolor     (%d)\n",BSVcolor);
        
        glUniformMatrix4fv(BSmodel     ,1,GL_FALSE,value_ptr(mat4()));
        glUniformMatrix4fv(BSview      ,1,GL_FALSE,value_ptr(mat4()));
        glUniformMatrix4fv(BSprojection,1,GL_FALSE,value_ptr(PROJECTION));
        glUniform4fv      (BSVcolor    ,1,value_ptr(palette[BASIC_WHITE]));
        checkGL(__FILE__,__LINE__);
        
        
        darkShader = shaderProgram(
            "src/shaders/vertex_dark.glsl",
            "src/shaders/fragment_dark.glsl"
        );
        currentShader(darkShader);
        checkGL(__FILE__,__LINE__);
        
        DSmodel      = glGetUniformLocation(darkShader,"model");
        DSview       = glGetUniformLocation(darkShader,"view");
        DSprojection = glGetUniformLocation(darkShader,"projection");
        DSVposition  = glGetAttribLocation( darkShader,"position");
        DSVcolor     = glGetAttribLocation( darkShader,"color");
        checkGL(__FILE__,__LINE__);
        
//        printf("DSmodel      (%d)\n",DSmodel);
//        printf("DSview       (%d)\n",DSview);
//        printf("DSprojection (%d)\n",DSprojection);
//        printf("DSVposition  (%d)\n",DSVposition);
//        printf("DSVcolor     (%d)\n",DSVcolor);
        
        glUniformMatrix4fv(DSmodel     ,1,GL_FALSE,value_ptr(mat4()));
        glUniformMatrix4fv(DSview      ,1,GL_FALSE,value_ptr(mat4()));
        glUniformMatrix4fv(DSprojection,1,GL_FALSE,value_ptr(PROJECTION));
        checkGL(__FILE__,__LINE__);
        
        
        lightShader = shaderProgram(
            "src/shaders/vertex_light.glsl",
            "src/shaders/fragment_light.glsl"
        );
        currentShader(lightShader);
        checkGL(__FILE__,__LINE__);
        
        LSmodel      = glGetUniformLocation(lightShader,"model");
        LSview       = glGetUniformLocation(lightShader,"view");
        LSprojection = glGetUniformLocation(lightShader,"projection");
        LSVposition  = glGetAttribLocation( lightShader,"position");
        LSVcolor     = glGetAttribLocation( lightShader,"color");
        LSVnormal    = glGetAttribLocation( lightShader,"normal");
        LSLposition  = glGetUniformLocation(lightShader,"light_position");
        LSLambient   = glGetUniformLocation(lightShader,"light_ambient");
        LSLdiffuse   = glGetUniformLocation(lightShader,"light_diffuse");
        LSLspecular  = glGetUniformLocation(lightShader,"light_specular");
        LSMshininess = glGetUniformLocation(lightShader,"material_shininess");
        LSMambient   = glGetUniformLocation(lightShader,"material_ambient");
        LSMdiffuse   = glGetUniformLocation(lightShader,"material_diffuse");
        LSMspecular  = glGetUniformLocation(lightShader,"material_specular");
        checkGL(__FILE__,__LINE__);
        
//        printf("LSmodel      (%d)\n",LSmodel);
//        printf("LSview       (%d)\n",LSview);
//        printf("LSprojection (%d)\n",LSprojection);
//        printf("LSVposition  (%d)\n",LSVposition);
//        printf("LSVcolor     (%d)\n",LSVcolor);
//        printf("LSVnormal    (%d)\n",LSVnormal);
//        printf("LSLposition  (%d)\n",LSLposition);
//        printf("LSLambient   (%d)\n",LSLambient);
//        printf("LSLdiffuse   (%d)\n",LSLdiffuse);
//        printf("LSLspecular  (%d)\n",LSLspecular);
//        printf("LSMshininess (%d)\n",LSMshininess);
//        printf("LSMambient   (%d)\n",LSMambient);
//        printf("LSMdiffuse   (%d)\n",LSMdiffuse);
//        printf("LSMspecular  (%d)\n",LSMspecular);
        
        glUniformMatrix4fv(LSmodel     ,1,GL_FALSE,value_ptr(mat4()));
        glUniformMatrix4fv(LSview      ,1,GL_FALSE,value_ptr(mat4()));
        glUniformMatrix4fv(LSprojection,1,GL_FALSE,value_ptr(PROJECTION));
        glUniform4fv      (LSLposition ,1,value_ptr(pLight));
        glUniform4fv      (LSLambient  ,1,value_ptr(light_ambient));
        glUniform4fv      (LSLdiffuse  ,1,value_ptr(light_diffuse));
        glUniform4fv      (LSLspecular ,1,value_ptr(light_specular));
        checkGL(__FILE__,__LINE__);
        
        
        glGenTextures(1,&defaultTexture);
        glBindTexture(GL_TEXTURE_2D,defaultTexture);
        glTexImage2D(
            GL_TEXTURE_2D,
            0,
            GL_RGBA8,
            texture.width,
            texture.height,
            0,
            GL_RGBA,GL_UNSIGNED_BYTE,
            texture.pixels
        );
        glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
        glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
        glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        glActiveTexture(GL_TEXTURE0);
        checkGL(__FILE__,__LINE__);
        
        
        standardShader = shaderProgram(
            "src/shaders/vertex.glsl",
            "src/shaders/fragment.glsl"
        );
        currentShader(standardShader);
        checkGL(__FILE__,__LINE__);
        
        SSmodel       = glGetUniformLocation(standardShader,"model");
        SSview        = glGetUniformLocation(standardShader,"view");
        SSprojection  = glGetUniformLocation(standardShader,"projection");
        SSVposition   = glGetAttribLocation( standardShader,"position");
        SSVcolor      = glGetAttribLocation( standardShader,"color");
        SSVnormal     = glGetAttribLocation( standardShader,"normal");
        SSTcoordinate = glGetAttribLocation( standardShader,"texture_coordinate");
        SSTmap        = glGetUniformLocation(standardShader,"texture_map");
        SSLposition   = glGetUniformLocation(standardShader,"light_position");
        SSLambient    = glGetUniformLocation(standardShader,"light_ambient");
        SSLdiffuse    = glGetUniformLocation(standardShader,"light_diffuse");
        SSLspecular   = glGetUniformLocation(standardShader,"light_specular");
        SSMshininess  = glGetUniformLocation(standardShader,"material_shininess");
        SSMambient    = glGetUniformLocation(standardShader,"material_ambient");
        SSMdiffuse    = glGetUniformLocation(standardShader,"material_diffuse");
        SSMspecular   = glGetUniformLocation(standardShader,"material_specular");
        checkGL(__FILE__,__LINE__);
        
//        printf("SSmodel       (%d)\n",SSmodel);
//        printf("SSview        (%d)\n",SSview);
//        printf("SSprojection  (%d)\n",SSprojection);
//        printf("SSVposition   (%d)\n",SSVposition);
//        printf("SSVcolor      (%d)\n",SSVcolor);
//        printf("SSVnormal     (%d)\n",SSVnormal);
//        printf("SSTcoordinate (%d)\n",SSTcoordinate);
//        printf("SSTmap        (%d)\n",SSTmap);
//        printf("SSLposition   (%d)\n",SSLposition);
//        printf("SSLambient    (%d)\n",SSLambient);
//        printf("SSLdiffuse    (%d)\n",SSLdiffuse);
//        printf("SSLspecular   (%d)\n",SSLspecular);
//        printf("SSMshininess  (%d)\n",SSMshininess);
//        printf("SSMambient    (%d)\n",SSMambient);
//        printf("SSMdiffuse    (%d)\n",SSMdiffuse);
//        printf("SSMspecular   (%d)\n",SSMspecular);
        
        glUniformMatrix4fv(SSmodel     ,1,GL_FALSE,value_ptr(mat4()));
        glUniformMatrix4fv(SSview      ,1,GL_FALSE,value_ptr(mat4()));
        glUniformMatrix4fv(SSprojection,1,GL_FALSE,value_ptr(PROJECTION));
        glUniform1i       (SSTmap      ,0);
        glUniform4fv      (SSLposition ,1,value_ptr(pLight));
        glUniform4fv      (SSLambient  ,1,value_ptr( light_ambient));
        glUniform4fv      (SSLdiffuse  ,1,value_ptr( light_diffuse));
        glUniform4fv      (SSLspecular ,1,value_ptr( light_specular));
        checkGL(__FILE__,__LINE__);
        
        printf("OpenGL v%s\n",glGetString(GL_VERSION));
        
        uninitialized = false;
    }
    else {
        
        currentShader(0);
        glDeleteProgram(standardShader);
        glDeleteProgram(   lightShader);
        glDeleteProgram(    darkShader);
        glDeleteProgram(   basicShader);
        checkGL(__FILE__,__LINE__);
        
        glBindTexture(GL_TEXTURE_2D,0);
        glDisable(GL_CULL_FACE);
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_BLEND);
        checkGL(__FILE__,__LINE__);
        
        uninitialized = true;
    }
}


void initialize ( ) {
    static bool uninitialized = true;
    if (uninitialized) {
        
        initGLFW();
        initGLEW();
        initGL();
        initFrame();
        
        uninitialized = false;
    }
    else {
        
        initFrame();
        initGL();
        initGLEW();
        initGLFW();
        
        uninitialized = true;
    }
}
