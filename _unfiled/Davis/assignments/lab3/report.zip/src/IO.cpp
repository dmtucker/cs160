static void error ( int error , const char * description ) { fputs(description,stderr); }


static void resize ( GLFWwindow * window , int width , int height ) {
    glViewport(0,0,width,height);
    if (not skew) updateProjection(PROJECTION);
    checkGL(__FILE__,__LINE__);
}


static void keyboard ( GLFWwindow * window , int key , int scancode , int action , int mods ) {
    switch (key) {
        default: return;
        // http://www.glfw.org/docs/latest/group__keys.html
        // http://www.glfw.org/docs/latest/group__mods.html
        
        case GLFW_KEY_A:
            if (mods == GLFW_MOD_CONTROL) switch (action) { // toggle axis
                case GLFW_PRESS: axis = not axis; break;
                case GLFW_RELEASE: moveL = false; break;
                default: break;
            }
            else switch (action) { // strafe left
                case GLFW_PRESS:
                case GLFW_REPEAT:  moveL = true;  break;
                case GLFW_RELEASE: moveL = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_C: // toggle culling
            if (mods == GLFW_MOD_CONTROL and action == GLFW_PRESS) {
                cull = not cull;
                if (cull) glEnable(GL_CULL_FACE);
                else     glDisable(GL_CULL_FACE);
                checkGL(__FILE__,__LINE__);
            }
            break;
        
        case GLFW_KEY_D: // strafe right
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  moveR = true;  break;
                case GLFW_RELEASE: moveR = false; break;
                default: break;
            }
            break;
            
        
        case GLFW_KEY_G: // toggle grid
            if (mods == GLFW_MOD_CONTROL and action == GLFW_PRESS) grid = not grid;
            break;
        
        case GLFW_KEY_SLASH: // usage
            if (mods != GLFW_MOD_SHIFT) break;
        case GLFW_KEY_H: // help
            if (action == GLFW_PRESS) {
                puts("\nCommands");
                puts("arrows     look around");
                puts("a,d,s,w    move camera around");
                puts("keypad     move light around");
                putchar('\n');
                puts("Controls");
                puts("ctrl-a     toggle axis");
                puts("ctrl-c     toggle culling");
                puts("ctrl-g     toggle grid");
                puts("ctrl-h     help");
                puts("ctrl-l     toggle lighting");
                puts("ctrl-p     toggle projection - perspective/orthographic");
                puts("ctrl-q     quit");
                puts("ctrl-s     toggle skew - normal/stretched");
                puts("ctrl-w     toggle wireframe - outline/fill primatives");
                puts("ctrl-z     toggle zooming - scroll to adjust the zoom/FOV");
                puts("ctrl-?     usage");
            }
            break;
        
        case GLFW_KEY_L: // toggle lighting
            if (mods == GLFW_MOD_CONTROL and action == GLFW_PRESS) toggleLights();
            break;
        
        case GLFW_KEY_P: // toggle projection
            if (mods == GLFW_MOD_CONTROL and action == GLFW_PRESS) lens = (lens) ? 0 : VERTICAL_FOV;
            break;
        
        case GLFW_KEY_Q: // quit
            if (mods == GLFW_MOD_CONTROL and action == GLFW_PRESS) glfwSetWindowShouldClose(window,GL_TRUE);
            break;
        
        case GLFW_KEY_S:
            if (mods == GLFW_MOD_CONTROL) switch (action) { // toggle skew
                case GLFW_PRESS: skew = not skew; break;
                case GLFW_RELEASE: moveB = false; break;
                default: break;
            }
            else switch (action) { // move backward
                case GLFW_PRESS:
                case GLFW_REPEAT:  moveB = true;  break;
                case GLFW_RELEASE: moveB = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_W:
            if (mods == GLFW_MOD_CONTROL) switch (action) {// toggle wireframe
                case GLFW_PRESS:
                    wire = not wire;
                    if (wire) glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
                    else      glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
                    checkGL(__FILE__,__LINE__);
                    break;
                case GLFW_RELEASE: moveF = false; break;
                default: break;
            }
            else switch (action) { // move forward
                case GLFW_PRESS:
                case GLFW_REPEAT:  moveF = true;  break;
                case GLFW_RELEASE: moveF = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_Z: // toggle zooming
            if (mods == GLFW_MOD_CONTROL and action == GLFW_PRESS) zooming = not zooming;
            break;
        
        case GLFW_KEY_PAGE_UP: // ascend
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  moveU = true;  break;
                case GLFW_RELEASE: moveU = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_PAGE_DOWN: // descend
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  moveD = true;  break;
                case GLFW_RELEASE: moveD = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_HOME: // orbit CW
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  orbitCW = true;  break;
                case GLFW_RELEASE: orbitCW = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_END: // orbit CCW
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  orbitCCW = true;  break;
                case GLFW_RELEASE: orbitCCW = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_LEFT: // look left
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  lookL = true;  break;
                case GLFW_RELEASE: lookL = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_RIGHT: // look right
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  lookR = true;  break;
                case GLFW_RELEASE: lookR = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_DOWN: // look down
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  lookD = true;  break;
                case GLFW_RELEASE: lookD = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_UP: // look up
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  lookU = true;  break;
                case GLFW_RELEASE: lookU = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_KP_2: // move light back
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  lightB = true;  break;
                case GLFW_RELEASE: lightB = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_KP_4: // move light left
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  lightL = true;  break;
                case GLFW_RELEASE: lightL = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_KP_6: // move light right
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  lightR = true;  break;
                case GLFW_RELEASE: lightR = false; break;
                default: break;
            }
            break;
            
        case GLFW_KEY_KP_8: // move light forth
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  lightF = true;  break;
                case GLFW_RELEASE: lightF = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_KP_SUBTRACT: // move light down
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  lightD = true;  break;
                case GLFW_RELEASE: lightD = false; break;
                default: break;
            }
            break;
        
        case GLFW_KEY_KP_ADD: // move light up
            switch (action) {
                case GLFW_PRESS:
                case GLFW_REPEAT:  lightU = true;  break;
                case GLFW_RELEASE: lightU = false; break;
                default: break;
            }
            break;
    }
}


static void click ( GLFWwindow * window , int button , int action , int mods ) {
    switch (button) {
        default: return;
        // http://www.glfw.org/docs/latest/group__buttons.html
        // http://www.glfw.org/docs/latest/group__mods.html
        case GLFW_MOUSE_BUTTON_LEFT:
        case GLFW_MOUSE_BUTTON_MIDDLE:
        case GLFW_MOUSE_BUTTON_RIGHT:  break;
    }
}


static void hover ( GLFWwindow * window , double xpos , double ypos ) {
    vCursor = vec3(xpos,ypos,1)-pCursor;
    pCursor = vec3(xpos,ypos,1);
}


static void scroll ( GLFWwindow * window , double xoffset , double yoffset ) {
    if (zooming) {
        const GLfloat s = 0.05;
             if (yoffset > 0) zoom += s;
        else if (yoffset < 0) zoom -= s;
    }
    else {
        const GLfloat s = 1.0;
             if (yoffset > 0) lens -= s;
        else if (yoffset < 0) lens += s;
    }
}
