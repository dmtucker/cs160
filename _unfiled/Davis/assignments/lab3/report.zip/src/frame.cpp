#include "drawings/cartesian.cpp"
//#include "drawings/terrain_basic.cpp"
#include "drawings/terrain_light.cpp"
//#include "drawings/terrain.cpp"
#include "drawings/RGBcube.cpp"
#include "drawings/fractal.cpp"
#include "drawings/sphere.cpp"


void initFrame ( ) {
    static bool uninitialized = true;
    if (uninitialized) {
        
        initCartesian();
        initTerrain();
        initSphere();
        
        GLfloat s = 10;
        
        initRGBcube();
        RGBcubeModel = scale(RGBcubeModel,vec3(s,s,s));
        
        initSierpinski();
        gasketModel  = scale(gasketModel,vec3(s,s,s));
        
        pEye   = vec4(500,500,500,1);
        pFocus = AXIS_ORIGIN;
        
        uninitialized = false;
    }
    else {
        
        initSierpinski();
        initRGBcube();
        initSphere();
        initTerrain();
        initCartesian();
        
        uninitialized = true;
    }
}


void drawTitle ( ) {
    sprintf(
        &title[0],
        "%dx%d (%d,%d) | %ds @ %d FPS | %d%% @ %ddeg %s %s %s %s %s frame",
        (int) windowW,   (int) windowH,
        (int) pCursor.x, (int) pCursor.y,
        (int) glfwGetTime(),
        (int) round(FPS),
        (int) round(zoom*100.0),
        (int) round(lens),
        (skew) ?     "stretch" : "normal",
        (lens) ? "perspective" : "orthographic",
        (cull) ?      "culled" : "unculled",
        (wire) ?        "wire" : "solid",
        (lighting) ?     "lit" : "dark"
    );
    glfwSetWindowTitle(defaultWindow,&title[0]);
}


void drawFrame ( ) {
    drawCartesian();
    drawTerrain();
    if (lighting) {
        sphereModel = translate(mat4(),vec3(pLight));
        drawSphere();
    }
//    drawRGBcube();
//    drawSierpinski();
}
