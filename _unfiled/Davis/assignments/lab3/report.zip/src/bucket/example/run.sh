g++ -std=gnu++11 org.cpp -lglfw3 -lGLEW -lGL -lX11 -lpthread -lXi -lXrandr -lXxf86vm
./a.out

