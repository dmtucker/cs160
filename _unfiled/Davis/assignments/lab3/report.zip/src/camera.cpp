void updateView ( mat4 view ) {
    
    currentShader(basicShader);
    glUniformMatrix4fv(BSview,1,GL_FALSE,value_ptr(view));
    
    currentShader(darkShader);
    glUniformMatrix4fv(DSview,1,GL_FALSE,value_ptr(view));
    
    currentShader(lightShader);
    glUniformMatrix4fv(LSview,1,GL_FALSE,value_ptr(view));
}


void updateProjection ( mat4 projection ) {
    
    currentShader(basicShader);
    glUniformMatrix4fv(BSprojection,1,GL_FALSE,value_ptr(projection));
    
    currentShader(darkShader);
    glUniformMatrix4fv(DSprojection,1,GL_FALSE,value_ptr(projection));
    
    currentShader(lightShader);
    glUniformMatrix4fv(LSprojection,1,GL_FALSE,value_ptr(projection));
}


void moveCamera ( ) {
    
    vec4 vForward = normalize(pFocus-pEye);
    vec4 vRight   = vec4(cross(vec3(vForward),vec3(vUp)),0);
    pFocus = vForward+pEye;
    
    mat4 path = mat4();
    const GLfloat velocity = 3.5;
    if (orbitCW xor orbitCCW) path = (orbitCCW) ?
                       rotate(path, velocity,vec3(vUp)):
                       rotate(path,-velocity,vec3(vUp));
    pEye = path*pEye;
    
    mat4 movement = mat4();
    const GLfloat agility = 12.0;
    if (moveL xor moveR) movement = (moveR) ?
               translate(movement,vec3( vRight  *agility)):
               translate(movement,vec3(-vRight  *agility));
    if (moveU xor moveD) movement = (moveU) ?
               translate(movement,vec3( vUp     *agility)):
               translate(movement,vec3(-vUp     *agility));
    if (moveB xor moveF) movement = (moveF) ?
               translate(movement,vec3( vForward*agility)):
               translate(movement,vec3(-vForward*agility));
    pEye   = movement*pEye;
    pFocus = movement*pFocus;
    
    mat4 rotation = mat4();
    const GLfloat sensitivity = 3.5;
    if (lookL xor lookR) rotation = (lookL) ?
                  rotate(rotation, sensitivity,vec3(vUp)):
                  rotate(rotation,-sensitivity,vec3(vUp));
    if (lookU xor lookD) rotation = (lookU) ?
                  rotate(rotation, sensitivity,vec3(vRight)):
                  rotate(rotation,-sensitivity,vec3(vRight));
    pFocus = pEye+(rotation*vForward);
    
    mat4 view = lookAt(vec3(pEye),vec3(pFocus),vec3(vUp));
         view =  scale(view,vec3(zoom,zoom,zoom));
    updateView(view);
    if (not skew) updateProjection(PROJECTION);
    
    
    movement = mat4();
    if (lightL xor lightR) movement = (lightR) ?
                 translate(movement,vec3( vRight  *agility)):
                 translate(movement,vec3(-vRight  *agility));
    if (lightU xor lightD) movement = (lightU) ?
                 translate(movement,vec3( vUp     *agility)):
                 translate(movement,vec3(-vUp     *agility));
    if (lightB xor lightF) movement = (lightF) ? //XXX Project onto the XZ plane.
                 translate(movement,vec3( vForward*agility)):
                 translate(movement,vec3(-vForward*agility));
    pLight = movement*pLight;
    
    currentShader(lightShader);
    glUniform4fv(LSLposition,1,value_ptr(pLight));
}


bool toggleLights ( bool enable = not lighting ) {
    
    static vec4 previous_ambient,
                previous_diffuse,
                previous_specular;
    
    if (enable) {
        light_ambient  = previous_ambient;
        light_diffuse  = previous_diffuse;
        light_specular = previous_specular;
    }
    else {
        previous_ambient  = light_ambient;
        previous_diffuse  = light_diffuse;
        previous_specular = light_specular;
        
        const GLfloat dark = 0.025;
        light_ambient  = vec4(dark,dark,dark,1);
        light_diffuse  = vec4(dark,dark,dark,1);
        light_specular = vec4(0,0,0,1);
    }
    
    currentShader(lightShader);
    glUniform4fv(LSLambient  ,1,value_ptr(light_ambient));
    glUniform4fv(LSLdiffuse  ,1,value_ptr(light_diffuse));
    glUniform4fv(LSLspecular ,1,value_ptr(light_specular));
    lighting = enable;
}
