#include <stdlib.h>
#include <stdio.h>

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
//#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/projection.hpp>
#include <glm/gtc/type_ptr.hpp>
using namespace glm;

#include "ppm_canvas.h"


// David Tucker <dmtucker@ucsc.edu> ////////////////////////////////////////////
#define CHECKPOINT(message) fprintf(stderr,"%s:%d:%s\n",__FILE__,__LINE__,message)
//CHECKPOINT("CHECKPOINT"); checkGL(__FILE__,__LINE__); //XXX

#define VOID(x) ((void *) (x))

bool checkGL ( const char * file , const unsigned int line , const bool required = false ) {
    const GLenum status = glGetError();
    if (status != GL_NO_ERROR) {
        fprintf(stderr,"%s:%d %s\n",gluErrorString(status));
        if (required) exit(EXIT_FAILURE);
        return false;
    }
    return true;
}

GLuint currentShader ( int shaderProgram = -1 ) {
    static GLuint current = 0;
    if (shaderProgram > -1) {
        current = shaderProgram;
        glUseProgram(current);
    }
    return current;
}

#include "globals.cpp"
#include   "frame.cpp"
#include  "camera.cpp"
#include      "IO.cpp"
#include    "init.cpp"


int main ( int argc , char * argv[] ) {
    
    if (argc < 3) {
        fprintf(stderr,"usage: %s [terrain] [texture]\n",argv[0]);
        return EXIT_FAILURE;
    }
    if (ppmLoadCanvas(argv[1],&terrain) != 0) puts("Terrain Load Failure");
    if (ppmLoadCanvas(argv[2],&texture) != 0) puts("Texture Load Failure"); //XXX
    
    initialize();
    while (not glfwWindowShouldClose(defaultWindow)) {
        
        glfwGetWindowPos (defaultWindow,&windowX,&windowY);
        glfwGetWindowSize(defaultWindow,&windowW,&windowH);
        
        if (FPS <= MAX_FPS) {
            
            static vec3 pPrevious = pCursor;
                          vCursor = pCursor-pPrevious;
                        pPrevious = pCursor;
            
            moveCamera();
            
            glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
            drawTitle();
            drawFrame();
            glfwSwapBuffers(defaultWindow);
            ++frames;
        }
        glfwPollEvents();
    }
    initialize();
    return EXIT_SUCCESS;
}
